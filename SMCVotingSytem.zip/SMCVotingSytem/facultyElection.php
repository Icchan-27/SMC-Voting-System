<?php
session_start();
include("connect.php");

if (!isset($_SESSION['faculty_id'])) {
    header("Location: login.php");
    exit();
}

$faculty_id = $_SESSION['faculty_id'];
$college_id = $_SESSION['college_id'];

$checkFaculty = $conn->prepare("SELECT * FROM faculty WHERE faculty_id = ?");
$checkFaculty->bind_param("i", $faculty_id);
$checkFaculty->execute();
$result = $checkFaculty->get_result();
if ($result->num_rows === 0) {
    header("Location: login.php");
    exit();
}
$checkFaculty->close();

$stmt = $conn->prepare("SELECT * FROM elections WHERE college_id=? AND status='Ongoing'");
$stmt->bind_param("i", $college_id);
$stmt->execute();
$ongoing = $stmt->get_result()->num_rows;
$stmt->close();

if ($ongoing > 0) {
    header("Location: nomination.php?readonly=faculty");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $electionName = $_POST['electionName'];
    $organization = $_POST['organization'];
    $description = "";

    $stmt = $conn->prepare("
        INSERT INTO elections 
        (electionName, description, start_date, end_date, status, organization, created_by, college_id) 
        VALUES (?, ?, NOW(), NULL, 'Ongoing', ?, ?, ?)
    ");
    $stmt->bind_param("sssii", $electionName, $description, $organization, $faculty_id, $college_id);
    $stmt->execute();
    $electionId = $stmt->insert_id;
    $stmt->close();

    if (!empty($_POST['position']) && !empty($_POST['winners'])) {
        foreach ($_POST['position'] as $index => $positionName) {
            $winners = $_POST['winners'][$index];
            $normalizedPosition = strtolower(trim($positionName));

            if (!empty($normalizedPosition) && !empty($winners)) {
                $check = $conn->prepare("SELECT student_position_id FROM student_positions WHERE LOWER(student_position_name)=?");
                $check->bind_param("s", $normalizedPosition);
                $check->execute();
                $res = $check->get_result();

                if ($res->num_rows > 0) {
                    $row = $res->fetch_assoc();
                    $positionId = $row['student_position_id'];
                } else {
                    $stmtPos = $conn->prepare("INSERT INTO student_positions (student_position_name) VALUES (?)");
                    $stmtPos->bind_param("s", $positionName);
                    $stmtPos->execute();
                    $positionId = $stmtPos->insert_id;
                    $stmtPos->close();
                }
                $check->close();

                $stmtLink = $conn->prepare("INSERT INTO election_position (election_id, student_position_id, num_winners) VALUES (?, ?, ?)");
                $stmtLink->bind_param("iii", $electionId, $positionId, $winners);
                $stmtLink->execute();
                $stmtLink->close();
            }
        }
    }

    echo "<script>alert('Election successfully created and is now ongoing!'); window.location.href='nomination.php?readonly=faculty';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Voting</title>
<style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
        height: 100vh;
        overflow: hidden;
    }
    .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .logout-btn {
        background-color: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: 0.3s;
    }
    .logout-btn:hover {
        background-color: #e6e6e6;
    }
    .container {
        display: flex;
        height: calc(100vh - 60px);
        overflow: hidden;
    }
    .sidebar {
        width: 200px;
        background-color: #f0f0f0;
        padding: 2rem 1rem;
        box-sizing: border-box;
    }
    .sidebar a {
        display: block;
        padding: 0.5rem 1rem;
        margin-bottom: 0.5rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
    }
    .sidebar a.active {
        background-color: #a6c8ff;
    }
    .main {
        flex: 1;
        margin: 1rem;
        padding: 1.5rem;
        box-sizing: border-box;
        background-color: white;
        border-radius: 1rem;
        display: flex;
        flex-direction: column;
        overflow-y: auto;
    }
    #voteForm {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }
    .form-group {
        display: flex;
        gap: 1rem;
        align-items: center;
    }
    .form-group label {
        min-width: 120px;
        text-align: right;
    }
    .form-group input[type="text"] {
        padding: 0.5rem 1rem;
        font-size: 1rem;
        border-radius: 100px;
        border: 1px solid #ccc;
        outline: none;
        width: 200px;
    }
    #positionsHeader {
        display: flex;
        justify-content: space-between;
        font-weight: bold;
        margin-bottom: 0.5rem;
    }
    #positionsContainer {
        display: flex;
        gap: 2rem;
    }
    .positions-column {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        flex: 1;
        align-items: center;
    }
    .positions-column input[type="text"],
    .positions-column input[type="number"] {
        padding: 0.5rem 1rem;
        border-radius: 100px;
        border: 1px solid #ccc;
        width: 80%;
        box-sizing: border-box;
        text-align: center;
    }
    #addCandidate {
        background-color: #cce0ff;
        border: none;
        font-size: 1.5rem;
        padding: 0.5rem 1rem;
        border-radius: 1rem;
        cursor: pointer;
        margin: 1rem auto 0 auto;
    }
    .form-actions {
        margin-top: auto;
        display: flex;
        justify-content: flex-start;
    }
    #submitVote {
        background-color: #4099ff;
        color: white;
        border: none;
        padding: 0.75rem 1.5rem;
        font-size: 1rem;
        border-radius: 1rem;
        cursor: pointer;
    }
    #submitVote:hover {
        background-color: #2a7de1;
    }
    .form-group select {
        padding: 0.5rem 1rem;
        font-size: 1rem;
        border-radius: 100px;
        border: 1px solid #ccc;
        outline: none;
        width: 200px;
        text-align: center;
    }
    .modal {
        display: none;
        position: fixed;
        top: 0; 
        left: 0;
        width: 100%; 
        height: 100%;
        background: rgba(0,0,0,0.5);
        justify-content: center;
        align-items: center;
    }
    .modal-content {
        background: white;
        padding: 2rem;
        border-radius: 1rem;
        max-width: 500px;
        width: 90%;
    }
    .modal-buttons {
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
        margin-top: 1rem;
    }
    .btn {
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        cursor: pointer;
    }
    .btn-yes {
        background: #4099ff;
        color: white;
    }
    .btn-no {
        background: #ccc;
    }
</style>
</head>
<body>
<div class="header">
    <div>SMC Council Voting</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>
<div class="container">
    <div class="sidebar">
        <a href="facultyHomePage.php">Home</a>
        <a href="#" class="active">Election</a>
        <a href="nomination.php?readonly=faculty">Nominations</a>
        <a href="#">Winners</a>
        <a href="#">College Officers</a>
    </div>
    <div class="main">
        <form id="voteForm" action="" method="POST">
            <div class="form-group">
                <label for="electionName">Election Name:</label>
                <input type="text" id="electionName" name="electionName" placeholder="Election Name" required>
            </div>
            <div class="form-group">
                <label for="organization">Organization Name:</label>
                <input type="text" id="organization" name="organization" placeholder="Organization" required>
            </div>
            <div id="positionsHeader">
                <span style="text-align:center; flex:1;">Positions</span>
                <span style="text-align:center; flex:1;">No. of Winners</span>
            </div>
            <div id="positionsContainer">
                <div class="positions-column" id="positionColumn">
                    <input type="text" name="position[]" placeholder="Enter Position">
                </div>
                <div class="positions-column" id="winnerColumn">
                    <input type="number" name="winners[]" placeholder="No. of Winners">
                </div>
            </div>
            <button type="button" id="addCandidate">+</button>
            <div class="form-actions">
                <button type="submit" id="submitVote">Submit</button>
            </div>
        </form>
    </div>
</div>
<div class="modal" id="confirmModal">
    <div class="modal-content">
        <h3>Confirm Submission</h3>
        <pre id="summaryText"></pre>
        <div class="modal-buttons">
            <button class="btn btn-no" id="cancelBtn">No</button>
            <button class="btn btn-yes" id="confirmBtn">Yes</button>
        </div>
    </div>
</div>
<script>
document.getElementById('addCandidate').addEventListener('click', function() {
    const positionColumn = document.getElementById('positionColumn');
    const winnerColumn = document.getElementById('winnerColumn');
    const posInput = document.createElement('input');
    posInput.type = 'text';
    posInput.name = 'position[]';
    posInput.placeholder = 'Enter Position';
    positionColumn.appendChild(posInput);
    const winnerInput = document.createElement('input');
    winnerInput.type = 'number';
    winnerInput.name = 'winners[]';
    winnerInput.placeholder = 'No. of Winners';
    winnerColumn.appendChild(winnerInput);
});

document.getElementById('voteForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (!this.checkValidity()) {
        alert("⚠️ Please fill out all required fields before submitting.");
        return;
    }
    const positions = document.getElementsByName('position[]');
    const winners = document.getElementsByName('winners[]');
    let valid = false;
    for (let i = 0; i < positions.length; i++) {
        const pos = positions[i].value.trim();
        const win = winners[i].value.trim();
        if ((pos && !win) || (!pos && win)) {
            alert("⚠️ Each Position must have a matching No. of Winners (and vice versa).");
            return;
        }
        if (pos && win) valid = true;
    }
    if (!valid) {
        alert("⚠️ Please enter at least one Position with its No. of Winners.");
        return;
    }
    const electionName = document.getElementById('electionName').value.trim();
    const organization = document.getElementById('organization').value.trim();
    let summary = "Election Name: " + electionName + "\nOrganization: " + organization + "\n\nPositions:\n";
    for (let i = 0; i < positions.length; i++) {
        if (positions[i].value.trim() && winners[i].value.trim()) {
            summary += "- " + positions[i].value.trim() + " (" + winners[i].value.trim() + " winner(s))\n";
        }
    }
    document.getElementById('summaryText').textContent = summary;
    document.getElementById('confirmModal').style.display = 'flex';
});

document.getElementById('cancelBtn').addEventListener('click', function() {
    document.getElementById('confirmModal').style.display = 'none';
});

document.getElementById('confirmBtn').addEventListener('click', function() {
    document.getElementById('voteForm').submit();
});
</script>
</body>
</html>