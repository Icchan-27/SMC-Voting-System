<?php
session_start();
include("connect.php");

if (!isset($_SESSION['facultyID'])) {
    header("Location: login.php");
    exit();
}

$facultyID = $_SESSION['facultyID'];
$collegeID = $_SESSION['collegeID'];

$checkFaculty = $conn->prepare("
    SELECT facultyID, collegeID
    FROM faculty
    WHERE facultyID = ? AND collegeID = ?
");
if (!$checkFaculty) {
    die("Faculty check error: " . $conn->error);
}
$checkFaculty->bind_param("ii", $facultyID, $collegeID);
$checkFaculty->execute();
$faculty = $checkFaculty->get_result()->fetch_assoc();
$checkFaculty->close();

if (!$faculty) {
    header("Location: login.php");
    exit();
}

$checkExisting = $conn->prepare("
    SELECT electionID, status
    FROM election
    WHERE collegeID = ?
    ORDER BY electionID DESC
    LIMIT 1
");
if (!$checkExisting) {
    die("Election check error: " . $conn->error);
}
$checkExisting->bind_param("i", $collegeID);
$checkExisting->execute();
$existingElection = $checkExisting->get_result()->fetch_assoc();
$checkExisting->close();

if ($existingElection) {
    if ($existingElection['status'] === 'Nominating' || $existingElection['status'] === 'Nomination') {
        header("Location: facultyNomination.php");
        exit();
    }

    if ($existingElection['status'] === 'Voting') {
        header("Location: facultyTabulation.php");
        exit();
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $electionName = trim($_POST['electionName'] ?? '');

    if ($electionName === '') {
        echo "<script>alert('Election name is required.'); window.location.href='facultyElection.php';</script>";
        exit();
    }

    $checkExisting = $conn->prepare("
        SELECT electionID, status
        FROM election
        WHERE collegeID = ?
        ORDER BY electionID DESC
        LIMIT 1
    ");
    if (!$checkExisting) {
        die("Election check error: " . $conn->error);
    }
    $checkExisting->bind_param("i", $collegeID);
    $checkExisting->execute();
    $existingElection = $checkExisting->get_result()->fetch_assoc();
    $checkExisting->close();

    if ($existingElection) {
        if ($existingElection['status'] === 'Nominating' || $existingElection['status'] === 'Nomination') {
            header("Location: facultyNomination.php");
            exit();
        }

        if ($existingElection['status'] === 'Voting') {
            header("Location: facultyTabulation.php");
            exit();
        }
    }

    $stmt = $conn->prepare("
        INSERT INTO election (collegeID, facultyID, electionName, startDate, endDate, status)
        VALUES (?, ?, ?, NOW(), NULL, 'Nominating')
    ");
    if (!$stmt) {
        die("Insert election error: " . $conn->error);
    }

    $stmt->bind_param("iis", $collegeID, $facultyID, $electionName);

    if (!$stmt->execute()) {
        die("Execute election insert error: " . $stmt->error);
    }

    $electionID = $stmt->insert_id;
    $stmt->close();

    if (!empty($_POST['position']) && !empty($_POST['winners'])) {
        foreach ($_POST['position'] as $index => $positionName) {
            $positionName = trim($_POST['position'][$index] ?? '');
            $winners = (int)($_POST['winners'][$index] ?? 0);

            if ($positionName !== '' && $winners > 0) {
                $stmtPos = $conn->prepare("
                    INSERT INTO `position` (electionID, positionName, winners)
                    VALUES (?, ?, ?)
                ");
                if (!$stmtPos) {
                    die("Insert position error: " . $conn->error);
                }

                $stmtPos->bind_param("isi", $electionID, $positionName, $winners);

                if (!$stmtPos->execute()) {
                    die("Execute position insert error: " . $stmtPos->error);
                }

                $stmtPos->close();
            }
        }
    }

    header("Location: facultyNomination.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Voting</title>
<style>
    * { box-sizing: border-box; }
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
        min-height: 100vh;
        overflow: hidden;
    }
    .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .logout-btn {
        background-color: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: 0.3s;
    }
    .logout-btn:hover { background-color: #e6e6e6; }
    .container {
        display: flex;
        min-height: calc(100vh - 67px);
    }
    .sidebar {
        width: 220px;
        background-color: #f0f0f0;
        padding: 2rem 1rem;
    }
    .sidebar a {
        display: block;
        padding: 0.65rem 1rem;
        margin-bottom: 0.6rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
    }
    .sidebar a.active { background-color: #a6c8ff; }
    .main {
        flex: 1;
        margin: 1rem;
        padding: 1.5rem;
        background-color: white;
        border-radius: 1rem;
        display: flex;
        flex-direction: column;
        overflow-y: auto;
    }
    #voteForm {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }
    .form-group {
        display: flex;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
    }
    .form-group label {
        width: 170px;
        font-weight: bold;
    }
    .form-group input[type="text"] {
        flex: 1;
        min-width: 250px;
        padding: 0.75rem 1rem;
        font-size: 1rem;
        border-radius: 999px;
        border: 1px solid #ccc;
        outline: none;
    }
    #positionsHeader {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        font-weight: bold;
        margin-top: 0.5rem;
        text-align: center;
    }
    #positionsContainer {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        align-items: start;
    }
    .positions-column {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
        align-items: center;
    }
    .positions-column input[type="text"],
    .positions-column input[type="number"] {
        width: 100%;
        max-width: 360px;
        padding: 0.75rem 1rem;
        border-radius: 999px;
        border: 1px solid #ccc;
        text-align: center;
        font-size: 1rem;
    }
    #addCandidate {
        align-self: center;
        background-color: #cce0ff;
        border: none;
        font-size: 1.5rem;
        padding: 0.5rem 1rem;
        border-radius: 1rem;
        cursor: pointer;
    }
    #addCandidate:hover { background-color: #b7d2ff; }
    .form-actions {
        display: flex;
        justify-content: flex-start;
    }
    #submitVote {
        background-color: #4099ff;
        color: white;
        border: none;
        padding: 0.85rem 1.75rem;
        font-size: 1rem;
        border-radius: 1rem;
        cursor: pointer;
    }
    #submitVote:hover { background-color: #2a7de1; }
    .modal {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        padding: 1rem;
    }
    .modal-content {
        background: white;
        padding: 2rem;
        border-radius: 1rem;
        max-width: 500px;
        width: 100%;
    }
    .modal-content h3 { margin-top: 0; }
    .modal-buttons {
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
        margin-top: 1rem;
    }
    .btn {
        padding: 0.6rem 1.2rem;
        border: none;
        border-radius: 1rem;
        cursor: pointer;
    }
    .btn-yes {
        background: #4099ff;
        color: white;
    }
    .btn-no { background: #ccc; }
    pre {
        white-space: pre-wrap;
        word-wrap: break-word;
        font-family: Arial, sans-serif;
    }
    @media (max-width: 768px) {
        .container {
            flex-direction: column;
            height: auto;
        }
        .sidebar {
            width: 100%;
            display: flex;
            gap: 0.5rem;
            overflow-x: auto;
            padding: 1rem;
        }
        .sidebar a {
            margin-bottom: 0;
            white-space: nowrap;
        }
        .main { margin: 0.75rem; }
        #positionsHeader,
        #positionsContainer {
            grid-template-columns: 1fr;
            gap: 1rem;
        }
        .form-group {
            flex-direction: column;
            align-items: stretch;
        }
        .form-group label { width: auto; }
    }
</style>
</head>
<body>
<div class="header">
    <div>SMC Council Voting</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>

<div class="container">
    <div class="sidebar">
        <a href="facultyHomePage.php">Home</a>
        <a href="#" class="active">Election</a>
        <a href="facultyTabulation.php">Winners</a>
        <a href="#">College Officers</a>
    </div>

    <div class="main">
        <form id="voteForm" action="" method="POST">
            <div class="form-group">
                <label for="electionName">Election Name:</label>
                <input type="text" id="electionName" name="electionName" placeholder="Election Name" required>
            </div>

            <div id="positionsHeader">
                <span>Positions</span>
                <span>No. of Winners</span>
            </div>

            <div id="positionsContainer">
                <div class="positions-column" id="positionColumn">
                    <input type="text" name="position[]" placeholder="Enter Position">
                </div>
                <div class="positions-column" id="winnerColumn">
                    <input type="number" name="winners[]" placeholder="No. of Winners" min="1">
                </div>
            </div>

            <button type="button" id="addCandidate">+</button>

            <div class="form-actions">
                <button type="submit" id="submitVote">Submit</button>
            </div>
        </form>
    </div>
</div>

<div class="modal" id="confirmModal">
    <div class="modal-content">
        <h3>Confirm Submission</h3>
        <pre id="summaryText"></pre>
        <div class="modal-buttons">
            <button class="btn btn-no" id="cancelBtn" type="button">No</button>
            <button class="btn btn-yes" id="confirmBtn" type="button">Yes</button>
        </div>
    </div>
</div>

<script>
document.getElementById('addCandidate').addEventListener('click', function() {
    const positionColumn = document.getElementById('positionColumn');
    const winnerColumn = document.getElementById('winnerColumn');

    const posInput = document.createElement('input');
    posInput.type = 'text';
    posInput.name = 'position[]';
    posInput.placeholder = 'Enter Position';
    positionColumn.appendChild(posInput);

    const winnerInput = document.createElement('input');
    winnerInput.type = 'number';
    winnerInput.name = 'winners[]';
    winnerInput.placeholder = 'No. of Winners';
    winnerInput.min = '1';
    winnerColumn.appendChild(winnerInput);
});

document.getElementById('voteForm').addEventListener('submit', function(e) {
    e.preventDefault();

    if (!this.checkValidity()) {
        alert("Please fill out all required fields before submitting.");
        return;
    }

    const positions = document.getElementsByName('position[]');
    const winners = document.getElementsByName('winners[]');

    let valid = false;

    for (let i = 0; i < positions.length; i++) {
        const pos = positions[i].value.trim();
        const win = winners[i].value.trim();

        if ((pos && !win) || (!pos && win)) {
            alert("Each Position must have a matching No. of Winners.");
            return;
        }

        if (pos && win) valid = true;
    }

    if (!valid) {
        alert("Please enter at least one Position with its No. of Winners.");
        return;
    }

    const electionName = document.getElementById('electionName').value.trim();
    let summary = "Election Name: " + electionName + "\n\nPositions:\n";

    for (let i = 0; i < positions.length; i++) {
        if (positions[i].value.trim() && winners[i].value.trim()) {
            summary += "- " + positions[i].value.trim() + " (" + winners[i].value.trim() + " winner(s))\n";
        }
    }

    document.getElementById('summaryText').textContent = summary;
    document.getElementById('confirmModal').style.display = 'flex';
});

document.getElementById('cancelBtn').addEventListener('click', function() {
    document.getElementById('confirmModal').style.display = 'none';
});

document.getElementById('confirmBtn').addEventListener('click', function() {
    document.getElementById('voteForm').submit();
});
</script>
</body>
</html> 