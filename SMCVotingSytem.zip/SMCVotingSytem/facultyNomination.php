<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMC Council Voting</title>
    <style>
        body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
        }
        .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        box-sizing: border-box;
        }
        .container {
        display: flex;
        min-height: calc(100vh - 60px);
        }
        .sidebar {
        width: 200px;
        background-color: #f0f0f0;
        padding: 2rem 1rem;
        box-sizing: border-box;
        }
        .sidebar a {
        display: block;
        padding: 0.5rem 1rem;
        margin-bottom: 0.5rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
        }
        .sidebar a.active {
        background-color: #a6c8ff;
        }
        .main {
        flex: 1;
        padding: 2rem;
        box-sizing: border-box;
        display: flex;
        gap: 2rem;
        align-items: flex-start;
        }
        .profile {
        flex: 1;
        background-color: #a6c8ff;
        padding: 1rem;
        border-radius: 1rem;
        color: white;
        box-sizing: border-box;
        }
        .candidate-list {
        list-style: none;
        padding: 0;
        margin: 0;
        }
        .candidate-item {
        padding: 0.75rem 1rem;
        margin-bottom: 0.5rem;
        background: #4099ff;
        border-radius: 0.75rem;
        cursor: pointer;
        transition: background 0.2s;
        }
        .candidate-item:hover {
        background: #2f7ad9;
        }
        .history {
        flex: 1;
        background-color: white;
        border-radius: 1rem;
        overflow: hidden;
        }
        table {
        width: 100%;
        border-collapse: collapse;
        }
        table th, table td {
        padding: 0.75rem 1rem;
        text-align: left;
        border-bottom: 1px solid #eee;
        }
        table th {
        background-color: #d0e4ff;
        }
        .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        }
        .modal-content {
        background: white;
        padding: 20px;
        border-radius: 1rem;
        width: 300px;
        text-align: center;
        }
        .modal-content h3 {
        margin-bottom: 1rem;
        }
        .modal-content select, .modal-content button {
        margin-top: 10px;
        padding: 8px;
        width: 100%;
        border-radius: 0.5rem;
        border: 1px solid #ccc;
        }
        .modal-content button {
        background-color: #4099ff;
        color: white;
        border: none;
        cursor: pointer;
        }
        .sticky-button {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #4099ff;
        color: white;
        padding: 0.75rem 2rem;
        border-radius: 0.75rem;
        font-weight: bold;
        text-decoration: none;
        transition: background 0.2s;
        }
        .sticky-button:hover {
        background-color: #2f7ad9;
        }
    </style>
</head>
<body>
    <div class="header">SMC Council Voting</div>
    <div class="container">
        <div class="sidebar">
        <a href="facultyHomePage.php">Home</a>
        <a href="#" class="active">Election</a>
        <a href="#">Winners</a>
        <a href="#">College Officers</a>
        </div>
        <div class="main">
        <div class="profile">
            <ul class="candidate-list">
            <li class="candidate-item" data-name="John Doe">John Doe</li>
            <li class="candidate-item" data-name="Jane Smith">Jane Smith</li>
            <li class="candidate-item" data-name="Michael Cruz">Michael Cruz</li>
            <li class="candidate-item" data-name="Anna Reyes">Anna Reyes</li>
            <li class="candidate-item" data-name="David Lee">David Lee</li>
            <li class="candidate-item" data-name="Maria Lopez">Maria Lopez</li>
            <li class="candidate-item" data-name="Carlos Santos">Carlos Santos</li>
            <li class="candidate-item" data-name="Sophia Ramos">Sophia Ramos</li>
            <li class="candidate-item" data-name="Mark Villanueva">Mark Villanueva</li>
            <li class="candidate-item" data-name="Angela Torres">Angela Torres</li>
            <li class="candidate-item" data-name="Kevin Bautista">Kevin Bautista</li>
            <li class="candidate-item" data-name="Lara Mendoza">Lara Mendoza</li>
            </ul>
        </div>
        <div class="history">
            <table>
            <thead>
                <tr>
                <th>Date</th>
                <th>Position</th>
                <th>Votes</th>
                <th>Description</th>
                <th>Rank</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>March 28, 2025</td>
                <td>Governor</td>
                <td>29</td>
                <td>CCS 4th Student Council Election</td>
                <td>1st</td>
                </tr>
                <tr>
                <td>March 28, 2024</td>
                <td>Vice-Governor</td>
                <td>24</td>
                <td>CCS 3rd Student Council Election</td>
                <td>3rd</td>
                </tr>
            </tbody>
            </table>
        </div>
        </div>
    </div>

    <a href="voting.html" class="sticky-button">End Nomination</a>

    <div class="modal" id="nominateModal">
        <div class="modal-content">
        <h3 id="modalTitle"></h3>
        <select id="positionSelect">
            <option value="">Select Position</option>
            <option value="Governor">Governor</option>
            <option value="Vice-Governor">Vice-Governor</option>
            <option value="Secretary">Secretary</option>
            <option value="Treasurer">Treasurer</option>
            <option value="Auditor">Auditor</option>
            <option value="PRO">PRO</option>
        </select>
        <button id="confirmNomination">Nominate</button>
        </div>
    </div>

    <script>
        const modal = document.getElementById("nominateModal")
        const modalTitle = document.getElementById("modalTitle")
        const positionSelect = document.getElementById("positionSelect")
        const confirmButton = document.getElementById("confirmNomination")
        let selectedName = ""

        document.querySelectorAll(".candidate-item").forEach(item => {
        item.addEventListener("click", () => {
            selectedName = item.getAttribute("data-name")
            modalTitle.textContent = "Nominate " + selectedName
            positionSelect.value = ""
            modal.style.display = "flex"
        })
        })

        confirmButton.addEventListener("click", () => {
        if (positionSelect.value) {
            alert(selectedName + " nominated as " + positionSelect.value)
            modal.style.display = "none"
        } else {
            alert("Please select a position")
        }
        })

        window.addEventListener("click", e => {
        if (e.target === modal) {
            modal.style.display = "none"
        }
        })
    </script>
</body>
</html>
