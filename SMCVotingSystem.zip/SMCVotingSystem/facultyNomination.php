<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['facultyID'])) {
    header("Location: login.php");
    exit();
}

$facultyID = $_SESSION['facultyID'];
$collegeID = $_SESSION['collegeID'];

$stmt = $conn->prepare("
    SELECT facultyID, collegeID
    FROM faculty
    WHERE facultyID = ? AND collegeID = ?
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("ii", $facultyID, $collegeID);
$stmt->execute();
$facultyData = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$facultyData) {
    header("Location: login.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT electionID, electionName, collegeID, status
    FROM election
    WHERE collegeID = ?
    ORDER BY electionID DESC
    LIMIT 1
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $collegeID);
$stmt->execute();
$electionResult = $stmt->get_result();

if ($electionResult->num_rows === 0) {
    echo "<script>alert('No election available.'); window.location.href='facultyHomePage.php';</script>";
    exit();
}

$election = $electionResult->fetch_assoc();
$stmt->close();

if ($election['status'] === 'Voting') {
    header("Location: facultyTabulation.php");
    exit();
}

if ($election['status'] !== 'Nomination' && $election['status'] !== 'Nominating') {
    echo "<script>alert('No nomination phase currently available.'); window.location.href='facultyHomePage.php';</script>";
    exit();
}

$electionID = $election['electionID'];
$electionCollegeID = $election['collegeID'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['acceptNominee'])) {
        $nominationID = (int) $_POST['acceptNominee'];

        $stmt = $conn->prepare("
            UPDATE nomination
            SET status = 'Accepted'
            WHERE nominationID = ? AND electionID = ?
        ");
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        $stmt->bind_param("ii", $nominationID, $electionID);

        if (!$stmt->execute()) {
            die("Accept error: " . $stmt->error);
        }
        $stmt->close();

        header("Location: facultyNomination.php?updated=1");
        exit();
    }

    if (isset($_POST['rejectNominee'])) {
        $nominationID = (int) $_POST['rejectNominee'];

        $stmt = $conn->prepare("
            UPDATE nomination
            SET status = 'Rejected'
            WHERE nominationID = ? AND electionID = ?
        ");
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        $stmt->bind_param("ii", $nominationID, $electionID);

        if (!$stmt->execute()) {
            die("Reject error: " . $stmt->error);
        }
        $stmt->close();

        header("Location: facultyNomination.php?updated=1");
        exit();
    }

    if (isset($_POST['endNomination'])) {
        $stmt = $conn->prepare("
            SELECT 
                p.positionID,
                p.positionName,
                p.winners,
                COUNT(CASE WHEN n.status = 'Accepted' THEN 1 END) AS accepted_count
            FROM `position` p
            LEFT JOIN nomination n
                ON n.positionID = p.positionID
                AND n.electionID = p.electionID
            WHERE p.electionID = ?
            GROUP BY p.positionID, p.positionName, p.winners
        ");
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        $stmt->bind_param("i", $electionID);
        $stmt->execute();
        $checkResult = $stmt->get_result();

        $notComplete = [];
        while ($row = $checkResult->fetch_assoc()) {
            if ((int)$row['accepted_count'] < (int)$row['winners']) {
                $notComplete[] = $row['positionName'] . " (" . $row['accepted_count'] . "/" . $row['winners'] . ")";
            }
        }
        $stmt->close();

        if (!empty($notComplete)) {
            $msg = "Cannot end nomination. Incomplete positions: " . implode(", ", $notComplete);
            echo "<script>alert(" . json_encode($msg) . "); window.location.href='facultyNomination.php';</script>";
            exit();
        }

        $stmt = $conn->prepare("
            UPDATE election
            SET status = 'Voting'
            WHERE electionID = ?
        ");
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        $stmt->bind_param("i", $electionID);

        if (!$stmt->execute()) {
            die("End nomination error: " . $stmt->error);
        }
        $stmt->close();

        echo "<script>alert('Nomination ended successfully.'); window.location.href='facultyTabulation.php';</script>";
        exit();
    }
}

$students = [];
$stmt = $conn->prepare("
    SELECT studentID, idNumber, fullName, yearLevel
    FROM student
    WHERE collegeID = ?
    ORDER BY fullName ASC
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $electionCollegeID);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $students[] = $row;
}
$stmt->close();

$history = [];
$stmt = $conn->prepare("
    SELECT
        n.nominationID,
        s.fullName,
        p.positionName,
        n.status
    FROM nomination n
    INNER JOIN student s ON s.studentID = n.nomineeID
    INNER JOIN `position` p ON p.positionID = n.positionID
    WHERE n.electionID = ?
    ORDER BY n.nominationID DESC
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $electionID);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $history[] = $row;
}
$stmt->close();

$updated = isset($_GET['updated']) && $_GET['updated'] == '1';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Nomination</title>
<style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
    }

    .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logout-btn {
        background: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: background 0.3s;
    }

    .logout-btn:hover {
        background: #e6e6e6;
    }

    .container {
        display: flex;
        min-height: calc(100vh - 67px);
    }

    .sidebar {
        width: 220px;
        background-color: #f0f0f0;
        padding: 2rem 1rem;
    }

    .sidebar a {
        display: block;
        padding: 0.65rem 1rem;
        margin-bottom: 0.6rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
    }

    .sidebar a.active {
        background-color: #a6c8ff;
    }

    .main {
        flex: 1;
        padding: 2rem;
        display: flex;
        gap: 2rem;
        align-items: flex-start;
    }

    .profile {
        flex: 1.15;
        background-color: #a6c8ff;
        padding: 1.25rem;
        border-radius: 1rem;
        color: white;
        max-height: 78vh;
        overflow-y: auto;
    }

    .history {
        flex: 1;
        background-color: white;
        border-radius: 1rem;
        overflow: hidden;
        max-height: 78vh;
        overflow-y: auto;
    }

    .search-wrap {
        display: flex;
        gap: 0.75rem;
        margin-bottom: 1rem;
        padding-bottom: 0.35rem;
    }

    #searchInput {
        flex: 1;
        min-width: 0;
        padding: 0.85rem 1rem;
        border: none;
        border-radius: 0.8rem;
        font-size: 1rem;
        outline: none;
    }

    #searchBtn {
        padding: 0.85rem 1.2rem;
        border: none;
        border-radius: 0.8rem;
        background-color: white;
        color: #4099ff;
        font-weight: bold;
        cursor: pointer;
    }

    #searchBtn:hover {
        background-color: #eef5ff;
    }

    .candidate-list {
        list-style: none;
        padding: 0;
        margin: 0;
        padding-bottom: 0.8rem;
    }

    .candidate-item {
        padding: 0.9rem 1rem;
        margin-bottom: 0.75rem;
        background: #8aa9d6 !important;
        border-radius: 0.75rem;
        cursor: not-allowed !important;
        opacity: 0.75;
        user-select: none;
        pointer-events: none;
    }

    .candidate-item:hover {
        background: #8aa9d6 !important;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    table th, table td {
        padding: 0.85rem 1rem;
        text-align: left;
        border-bottom: 1px solid #eee;
        vertical-align: top;
    }

    table th {
        background-color: #d0e4ff;
        position: sticky;
        top: 0;
    }

    .action-form {
        display: inline-block;
        margin-right: 4px;
        margin-bottom: 4px;
    }

    .accept-btn, .reject-btn, .end-btn {
        border: none;
        padding: 8px 12px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
    }

    .accept-btn {
        background: #4caf50;
        color: white;
    }

    .reject-btn {
        background: #f44336;
        color: white;
    }

    .end-btn {
        position: fixed;
        right: 24px;
        bottom: 24px;
        background: #4099ff;
        color: white;
        padding: 12px 18px;
        border-radius: 12px;
    }

    .status-pending {
        color: #ff9800;
        font-weight: bold;
    }

    .status-accepted {
        color: #4caf50;
        font-weight: bold;
    }

    .status-rejected {
        color: #f44336;
        font-weight: bold;
    }

    @media (max-width: 900px) {
        .container {
            flex-direction: column;
        }

        .sidebar {
            width: 100%;
            padding: 1rem;
            display: flex;
            gap: 0.5rem;
            overflow-x: auto;
        }

        .sidebar a {
            white-space: nowrap;
            margin-bottom: 0;
        }

        .main {
            flex-direction: column;
        }

        .profile,
        .history {
            width: 100%;
            max-height: none;
        }
    }
</style>
</head>
<body>
    <div class="header">
        <div>SMC Council Nomination</div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="container">
        <div class="sidebar">
            <a href="facultyHomePage.php">Home</a>
            <a href="#" class="active">Election</a>
            <a href="facultyTabulation.php">Winners</a>
            <a href="#">College Officers</a>
        </div>

        <div class="main">
            <div class="profile">
                <div class="search-wrap">
                    <input type="text" id="searchInput" placeholder="Search candidate...">
                    <button type="button" id="searchBtn">Search</button>
                </div>

                <ul class="candidate-list" id="candidateList">
                    <?php foreach ($students as $student): ?>
                    <li class="candidate-item"
                        data-id="<?= (int)$student['studentID'] ?>"
                        data-name="<?= htmlspecialchars($student['fullName']) ?>">
                        <?= htmlspecialchars($student['fullName']) ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="history">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['fullName']) ?></td>
                            <td><?= htmlspecialchars($row['positionName']) ?></td>
                            <td class="status-<?= strtolower(trim(htmlspecialchars($row['status'] ?? 'Pending'))) ?>">
                                <?= htmlspecialchars($row['status'] ?? 'Pending') ?>
                            </td>
                            <td>
                                <?php if (strtolower(trim($row['status'] ?? 'Pending')) === 'pending'): ?>
                                    <form method="POST" class="action-form">
                                        <button type="submit" name="acceptNominee" value="<?= (int)$row['nominationID'] ?>" class="accept-btn">Accept</button>
                                    </form>
                                    <form method="POST" class="action-form">
                                        <button type="submit" name="rejectNominee" value="<?= (int)$row['nominationID'] ?>" class="reject-btn">Reject</button>
                                    </form>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <form method="POST">
        <button type="submit" name="endNomination" value="1" class="end-btn">End Nomination</button>
    </form>

    <script>
        const searchInput = document.getElementById("searchInput");
        const searchBtn = document.getElementById("searchBtn");

        function filterCandidates() {
            const value = searchInput.value.toLowerCase();
            document.querySelectorAll(".candidate-item").forEach(item => {
                const name = item.getAttribute("data-name").toLowerCase();
                item.style.display = name.includes(value) ? "block" : "none";
            });
        }

        searchBtn.addEventListener("click", filterCandidates);
        searchInput.addEventListener("keyup", filterCandidates);

        <?php if (!empty($updated)): ?>
        alert("Nomination updated successfully.");
        <?php endif; ?>
    </script>
</body>
</html>