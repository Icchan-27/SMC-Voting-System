<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['studentID'])) {
    header("Location: login.php");
    exit();
}

$studentID = $_SESSION['studentID'];

$stmt = $conn->prepare("
    SELECT s.studentID, s.IDnumber, s.fullName, s.userName, s.yearLevel, s.collegeID, c.collegeName
    FROM student s
    LEFT JOIN college c ON s.collegeID = c.collegeID
    WHERE s.studentID = ?
");
$stmt->bind_param("i", $studentID);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['isOfficer'])) {
    $_SESSION['isOfficer'] = false;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Voting</title>
<style>
    html, body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
        overflow: hidden;
    }
    .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .logout-btn {
        background-color: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: 0.3s;
    }
    .logout-btn:hover {
        background-color: #e6e6e6;
    }
.container {
    display: flex;
    min-height: calc(100vh - 67px);
}

.sidebar {
    width: 220px;
    background-color: #f0f0f0;
    padding: 2rem 1rem;
}

.sidebar a {
    display: block;
    padding: 0.65rem 1rem;
    margin-bottom: 0.6rem;
    color: black;
    text-decoration: none;
    border-radius: 1rem;
}

.sidebar a.active {
    background-color: #a6c8ff;
}
    .main {
        flex: 1;
        min-width: 0;
        padding: 2rem;
        display: flex;
        flex-direction: column;
        gap: 2rem;
        box-sizing: border-box;
    }
    .profile {
        display: flex;
        background-color: #a6c8ff;
        padding: 1rem;
        border-radius: 1rem;
        align-items: center;
        gap: 1rem;
        color: white;
    }
    .profile img {
        width: 100px;
        height: 100px;
        border-radius: 1rem;
        object-fit: cover;
        background-color: #fff;
    }
    .profile-details {
        line-height: 1.7;
    }
</style>
</head>
<body>
    <div class="header">
        <div>SMC Council Voting</div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="container">
        <div class="sidebar">
            <a href="#" class="active">Home</a>
            <a href="<?php echo (isset($_SESSION['isOfficer']) && $_SESSION['isOfficer']) ? 'nomination.php' : 'studentNomination.php'; ?>">
                Election
            </a>
            <a href="studentTabulation.php">Winners</a>
            <a href="electionWinners.php">College Officers</a>
        </div>

        <div class="main">
            <div class="profile">
                <img src="https://via.placeholder.com/100" alt="Profile Picture">
                <div class="profile-details">
                    <div>Name: <?php echo htmlspecialchars($student['fullName']); ?></div>
                    <div>Username: <?php echo htmlspecialchars($student['userName']); ?></div>
                    <div>ID Number: <?php echo htmlspecialchars($student['IDnumber']); ?></div>
                    <div>Year Level: <?php echo htmlspecialchars($student['yearLevel']); ?></div>
                    <div>College: <?php echo htmlspecialchars($student['collegeName'] ?? 'N/A'); ?></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>