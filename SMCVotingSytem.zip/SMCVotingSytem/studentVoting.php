<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$collegeId = $_SESSION['college_id'];

// Get ongoing election for this college
$stmt = $conn->prepare("
    SELECT e.election_id, e.electionName
    FROM elections e
    INNER JOIN election_position ep ON e.election_id = ep.election_id
    INNER JOIN nomination n ON ep.election_position_id = n.election_position_id
    WHERE e.status='Ongoing' AND e.college_id=?
    GROUP BY e.election_id
    LIMIT 1
");
$stmt->bind_param("i", $collegeId);
$stmt->execute();
$election = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$election) {
    echo "No voting is ongoing for your college.";
    exit();
}

$electionId = $election['election_id'];

// Check if the student already voted in this election
$check = $conn->prepare("
    SELECT 1 
    FROM votes v
    JOIN nomination n ON v.nomination_id = n.nomination_id
    JOIN election_position ep ON n.election_position_id = ep.election_position_id
    WHERE v.voter_id=? AND ep.election_id=? 
    LIMIT 1
");
$check->bind_param("ii", $_SESSION['student_id'], $electionId);
$check->execute();
$alreadyVoted = $check->get_result()->num_rows > 0;
$check->close();

if ($alreadyVoted) {
    header("Location: studentWinners.php");
    exit();
}
$stmt = $conn->prepare("
    SELECT sp.student_position_id, sp.student_position_name, 
    s.firstName, s.middleName, s.lastName, 
    n.nomination_id, ep.num_winners
    FROM nomination n
    JOIN student s ON n.candidate_id = s.student_id
    JOIN election_position ep ON n.election_position_id = ep.election_position_id
    JOIN student_positions sp ON ep.student_position_id = sp.student_position_id
    WHERE ep.election_id=? 
    ORDER BY sp.student_position_id ASC, s.lastName ASC
");
$stmt->bind_param("i", $electionId);
$stmt->execute();
$result = $stmt->get_result();

$candidates = [];
while ($row = $result->fetch_assoc()) {
    $posId = $row['student_position_id'];
    $pos = $row['student_position_name'];
    $name = trim($row['firstName'].' '.$row['middleName'].' '.$row['lastName']);
    $candidates[$posId]['name'] = $pos;
    $candidates[$posId]['limit'] = $row['num_winners'];
    $candidates[$posId]['cands'][] = [
        'name' => $name,
        'nomination_id' => $row['nomination_id']
    ];
}
$stmt->close();

$positions = $candidates;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Voting</title>
<style>
body {margin:0;font-family:Arial,sans-serif;background:#d9d9d9}
.header {width:100%;background:#4099ff;color:white;padding:1rem 2rem;font-size:1.5rem;font-weight:bold;box-sizing:border-box}
.container {display:flex;min-height:calc(100vh - 60px)}
.sidebar {width:200px;background:#f0f0f0;padding:2rem 1rem;box-sizing:border-box}
.sidebar a {display:block;padding:0.5rem 1rem;margin-bottom:0.5rem;color:black;text-decoration:none;border-radius:1rem}
.sidebar a.active {background:#a6c8ff}
.main {flex:1;margin:1rem;padding:1rem;box-sizing:border-box;background:white;border-radius:1rem;width:900px;display:flex;flex-direction:column;position:relative}
.blue-box {background:#4099ff;color:white;padding:1rem 2rem;border-radius:0.5rem;font-weight:bold;font-size:1.2rem;width:fit-content;margin-top:10px;margin-left:10px}
.big-blue-box {background:#4099ff;color:white;border-radius:0.5rem;margin-top:20px;margin-left:10px;width:96%;height:670px;padding:1rem;box-sizing:border-box;display:flex;flex-direction:column}
.table-container {flex:1;height:100%;overflow:auto;-webkit-overflow-scrolling:touch}
table {border-collapse:collapse;table-layout:auto;min-width:max-content;width:auto;height:100%}
th,td {border:1px solid white;padding:1rem;text-align:center;white-space:nowrap;min-width:150px;cursor:pointer;user-select:none;box-sizing:border-box;overflow:hidden;text-overflow:ellipsis}
th {background:#2f7ad9;font-size:1.1rem;position:sticky;top:0;z-index:2}
td {background:#66a3ff;transition:background 0.2s}
td:hover {background:#5b92e5}
td.selected {background:#a6c8ff!important}
.done-btn {background:#2f7ad9;color:white;padding:0.8rem 2rem;font-size:1rem;border:none;border-radius:1rem;cursor:pointer;margin:20px auto 0 auto;display:block;transition:background 0.2s}
.done-btn:hover {background:#1f5bbf}
.modal {display:none;position:fixed;z-index:999;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,0.6);align-items:center;justify-content:center}
.modal-content {background:white;padding:1.5rem;border-radius:1rem;text-align:center;max-width:400px;width:90%}
.modal-content h2 {margin-bottom:1rem;font-size:1.3rem}
.modal-btns {margin-top:20px;display:flex;justify-content:space-around}
.modal-btns button {padding:0.7rem 1.5rem;border:none;border-radius:0.5rem;cursor:pointer;font-size:1rem;min-width:100px}
.yes-btn {background:#2f7ad9;color:white}
.yes-btn:hover {background:#1f5bbf}
.no-btn {background:#d9534f;color:white}
.no-btn:hover {background:#c9302c}
</style>
</head>
<body>
<div class="header">SMC Council Voting</div>
<div class="container">
    <div class="sidebar">
        <a href="studentHomePage.php">Home</a>
        <a href="#" class="active">Election</a>
        <a href="#">Winners</a>
        <a href="#">College Officers</a>
    </div>
    <div class="main">
        <div class="blue-box">Voting - <?= htmlspecialchars($election['electionName']) ?></div>
        <div class="big-blue-box">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <?php foreach ($positions as $p): ?>
                                <th data-limit="<?= (int)$p['limit'] ?>">
                                    <?= htmlspecialchars($p['name']) ?>
                                </th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $maxRows = 0;
                        foreach ($positions as $p) {
                            $count = isset($p['cands']) ? count($p['cands']) : 0;
                            if ($count > $maxRows) $maxRows = $count;
                        }
                        for ($i=0; $i<$maxRows; $i++): ?>
                        <tr>
                            <?php foreach ($positions as $p): ?>
                                <td data-nomination-id="<?= isset($p['cands'][$i]) ? $p['cands'][$i]['nomination_id'] : '' ?>">
                                    <?= isset($p['cands'][$i]) ? htmlspecialchars($p['cands'][$i]['name']) : "---" ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <button class="done-btn" id="doneBtn">Done Voting</button>
    </div>
</div>

<div class="modal" id="confirmModal">
    <div class="modal-content">
        <h2>Confirm Your Votes</h2>
        <div id="voteSummary" style="margin:1rem 0;text-align:left"></div>
        <div class="modal-btns">
            <button id="yesBtn" class="yes-btn">Yes</button>
            <button id="noBtn" class="no-btn">No</button>
        </div>
    </div>
</div>

<script>
document.querySelectorAll("td").forEach(td=>{
    td.addEventListener("click",()=>{
        if(td.textContent.trim()==="---")return
        const colIndex=td.cellIndex
        const header=document.querySelector("thead th:nth-child("+(colIndex+1)+")")
        const limit=parseInt(header.getAttribute("data-limit"))||1
        const selectedCells=document.querySelectorAll("tbody tr td:nth-child("+(colIndex+1)+").selected")
        if(td.classList.contains("selected")){
            td.classList.remove("selected")
        }else{
            if(selectedCells.length>=limit){
                alert("You can only select up to "+limit+" candidate(s) for "+header.textContent.trim()+".")
                return
            }
            td.classList.add("selected")
        }
    })
})

const doneBtn = document.getElementById("doneBtn")
const modal = document.getElementById("confirmModal")
const noBtn = document.getElementById("noBtn")
const yesBtn = document.getElementById("yesBtn")
const summaryBox = document.getElementById("voteSummary")

doneBtn.addEventListener("click", () => {
    const headers = document.querySelectorAll("thead th")
    let invalid = false
    let summary = "<ul style='padding-left:20px;'>"

    headers.forEach((header, idx) => {
        const posName = header.textContent.trim()
        const limit = parseInt(header.getAttribute("data-limit")) || 1
        const selected = document.querySelectorAll(`tbody tr td:nth-child(${idx + 1}).selected`)
        
        if (selected.length !== limit) {
            alert(`You must select exactly ${limit} candidate(s) for ${posName}.`)
            invalid = true
            return
        }
        summary += `<li><strong>${posName}:</strong> ${Array.from(selected).map(td => td.textContent.trim()).join(", ")}</li>`
    })

    summary += "</ul>"
    if (invalid) return

    summaryBox.innerHTML = summary
    modal.style.display = "flex"
})

noBtn.addEventListener("click", () => { modal.style.display = "none" })

yesBtn.addEventListener("click", () => {
    const ids = Array.from(document.querySelectorAll("td.selected"))
                    .map(td => td.getAttribute("data-nomination-id"))
                    .filter(nid => nid)
    
    if (ids.length === 0) return

    fetch("save_votes.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nominations: ids })
    }).then(res => {
        // Redirect immediately after server handles vote
        window.location.href = "studentWinners.php"
    }).catch(err => {
        alert("Error saving votes: " + err.message)
    })
})

</script>
</body>
</html>