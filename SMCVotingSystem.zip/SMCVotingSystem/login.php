<?php
session_start();
include 'connect.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['userName'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$conn) {
        die("Database connection failed.");
    }

    $sqlStudent = "SELECT * FROM student WHERE userName = ? AND password = ?";
    $stmtStudent = $conn->prepare($sqlStudent);

    if (!$stmtStudent) {
        die("Student query error: " . $conn->error);
    }

    $stmtStudent->bind_param("ss", $username, $password);
    $stmtStudent->execute();
    $resultStudent = $stmtStudent->get_result();

    if ($resultStudent && $resultStudent->num_rows > 0) {
        $student = $resultStudent->fetch_assoc();

        $_SESSION['role'] = 'student';
        $_SESSION['userName'] = $student['userName'];
        $_SESSION['studentID'] = $student['studentID'];
        $_SESSION['collegeID'] = $student['collegeID'];

        $_SESSION['isOfficer'] = false;
        unset($_SESSION['officerID'], $_SESSION['officerElectionID'], $_SESSION['officerPositionID']);

        $stmtOfficer = $conn->prepare("
            SELECT officerID, electionID, positionID
            FROM officers
            WHERE studentID = ? AND status = 'Current'
        ");

        if (!$stmtOfficer) {
            die("Officer query error: " . $conn->error);
        }

        $stmtOfficer->bind_param("i", $student['studentID']);
        $stmtOfficer->execute();
        $resultOfficer = $stmtOfficer->get_result();

        if ($resultOfficer && $resultOfficer->num_rows > 0) {
            $officer = $resultOfficer->fetch_assoc();

            $_SESSION['isOfficer'] = true;
            $_SESSION['officerID'] = $officer['officerID'];
            $_SESSION['officerElectionID'] = $officer['electionID'];
            $_SESSION['officerPositionID'] = $officer['positionID'];
        }

        $stmtOfficer->close();
        $stmtStudent->close();

        header("Location: studentHomePage.php");
        exit();
    }

    $stmtStudent->close();

    $sqlFaculty = "SELECT * FROM faculty WHERE userName = ? AND password = ?";
    $stmtFaculty = $conn->prepare($sqlFaculty);

    if (!$stmtFaculty) {
        die("Faculty query error: " . $conn->error);
    }

    $stmtFaculty->bind_param("ss", $username, $password);
    $stmtFaculty->execute();
    $resultFaculty = $stmtFaculty->get_result();

    if ($resultFaculty && $resultFaculty->num_rows > 0) {
        $faculty = $resultFaculty->fetch_assoc();

        $_SESSION['role'] = 'faculty';
        $_SESSION['userName'] = $faculty['userName'];
        $_SESSION['facultyID'] = $faculty['facultyID'];
        $_SESSION['collegeID'] = $faculty['collegeID'];

        unset($_SESSION['studentID'], $_SESSION['isOfficer'], $_SESSION['officerID'], $_SESSION['officerElectionID'], $_SESSION['officerPositionID']);

        $stmtFaculty->close();

        header("Location: facultyHomePage.php");
        exit();
    }

    $stmtFaculty->close();

    $error = "Incorrect username or password.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Anton&display=swap');

    :root {
        font-size: 16px;
    }

    html, body {
        margin: 0;
        background-color: #ccc;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        font-family: sans-serif;
    }

    .square {
        width: 100%;
        height: 4rem;
        background-color: #4099ff;
        font-family: 'Anton', sans-serif;
        font-size: 2rem;
        color: white;
        display: flex;
        align-items: center;
        padding-left: 1rem;
    }

    .content {
        flex: 1;
        display: flex;
        justify-content: flex-end;
        align-items: stretch;
    }

    .login {
        flex: 0 1 25%;
        max-width: 400px;
        min-width: 280px;
        background: white;
        border-radius: 1rem 0 0 1rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 2rem 1.5rem;
    }

    .login h2 {
        font-family: 'Anton', sans-serif;
        font-size: 1.75rem;
        color: #4099ff;
        margin-bottom: 1.25rem;
        width: 100%;
        text-align: left;
    }

    .login input {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #ccc;
        border-radius: 2rem;
        font-size: 1rem;
        text-align: center;
        margin-bottom: 1rem;
        box-sizing: border-box;
    }

    .login button {
        width: 100%;
        padding: 0.85rem;
        border: none;
        border-radius: 2rem;
        background-color: #4099ff;
        color: white;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }

    .login button:hover {
        background-color: #3277cc;
    }

    .error {
        color: red;
        font-size: 0.9rem;
        margin: -0.5rem 0 1rem 0;
        width: 100%;
        text-align: center;
    }
</style>
</head>
<body>
<div class="square">MySMC Election</div>

<div class="content">
    <div class="login">
        <h2>Login</h2>
        <form method="POST">
            <input type="text" name="userName" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>

            <?php if (!empty($error)) { ?>
                <p class="error"><?php echo $error; ?></p>
            <?php } ?>

            <button type="submit">Login</button>
        </form>
    </div>
</div>
</body>
</html>