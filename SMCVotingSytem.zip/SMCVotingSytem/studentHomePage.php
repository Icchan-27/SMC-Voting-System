<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['idNumber'])) {
    header("Location: index.php");
    exit();
}

$idNumber = $_SESSION['idNumber'];

$stmt = $conn->prepare("SELECT s.student_id, s.firstName, s.middleName, s.lastName, s.email, s.role, c.collegeName, s.student_position_id FROM student s JOIN colleges c ON s.college_id = c.college_id WHERE s.idNumber = ?");
$stmt->bind_param("s", $idNumber);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

$studentId = $student['student_id'];

$sqlHistory = "SELECT e.start_date AS date, sp.student_position_name AS position, COUNT(v.vote_id) AS votes, e.description, RANK() OVER(PARTITION BY esp.election_id ORDER BY COUNT(v.vote_id) DESC) AS rank FROM nomination n JOIN election_position esp ON n.election_position_id = esp.election_position_id JOIN student_positions sp ON esp.election_position_id = sp.student_position_id JOIN elections e ON esp.election_id = e.election_id LEFT JOIN votes v ON n.nomination_id = v.nomination_id WHERE n.candidate_id = ? GROUP BY esp.election_position_id, n.candidate_id, e.start_date, sp.student_position_name, e.description ORDER BY e.start_date DESC";
$stmtHistory = $conn->prepare($sqlHistory);
$stmtHistory->bind_param("i", $studentId);
$stmtHistory->execute();
$historyResult = $stmtHistory->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Voting</title>
<style>
    html, body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
        overflow: hidden;
    }
    .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .logout-btn {
        background-color: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: 0.3s;
    }
    .logout-btn:hover {
        background-color: #e6e6e6;
    }
    .container {
        display: flex;
        flex-wrap: wrap;
        min-height: calc(100vh - 60px);
        box-sizing: border-box;
        width: 100%;
    }
    .sidebar {
        flex: 0 0 200px;
        max-width: 100%;
        background-color: #f0f0f0;
        padding: 2rem 1rem;
        box-sizing: border-box;
    }
    .sidebar a {
        display: block;
        padding: 0.5rem 1rem;
        margin-bottom: 0.5rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
    }
    .sidebar a.active {
        background-color: #a6c8ff;
    }
    .main {
        flex: 1;
        min-width: 0;
        padding: 2rem;
        display: flex;
        flex-direction: column;
        gap: 2rem;
        box-sizing: border-box;
    }
    .profile {
        display: flex;
        background-color: #a6c8ff;
        padding: 1rem;
        border-radius: 1rem;
        align-items: center;
        gap: 1rem;
        color: white;
    }
    .profile img {
        width: 100px;
        height: 100px;
        border-radius: 1rem;
        object-fit: cover;
        background-color: #fff;
    }
    .profile-details {
        line-height: 1.5;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: white;
        border-radius: 1rem;
        overflow: hidden;
        table-layout: fixed;
    }
    table th, table td {
        padding: 0.75rem 1rem;
        text-align: left;
        border-bottom: 1px solid #fff;
        word-wrap: break-word;
    }
    table th {
        background-color: #d0e4ff;
    }
</style>
</head>
<body>
    <div class="header">
        <div>SMC Council Voting</div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
    <div class="container">
        <div class="sidebar">
            <a href="#" class="active">Home</a>
            <a href="studentNomination.php">Election</a>
            <a href="#">Winners</a>
            <a href="#">College Officers</a>
        </div>
        <div class="main">
            <div class="profile">
                <img src="https://via.placeholder.com/100" alt="Profile Picture">
                <div class="profile-details">
                    <div>Name: <?php echo htmlspecialchars($student['firstName'] . " " . $student['middleName'] . " " . $student['lastName']); ?></div>
                    <div>College: <?php echo htmlspecialchars($student['collegeName']); ?></div>
                    <div>Role: <?php echo htmlspecialchars($student['role']); ?></div>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Position</th>
                        <th>Votes</th>
                        <th>Description</th>
                        <th>Rank</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $historyResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['date']); ?></td>
                        <td><?php echo htmlspecialchars($row['position']); ?></td>
                        <td><?php echo htmlspecialchars($row['votes']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td><?php echo htmlspecialchars($row['rank']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>