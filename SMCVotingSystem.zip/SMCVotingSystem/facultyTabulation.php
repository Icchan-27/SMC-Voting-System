<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['facultyID'])) {
    header("Location: login.php");
    exit();
}

$facultyID = $_SESSION['facultyID'];
$collegeID = $_SESSION['collegeID'];

$checkFaculty = $conn->prepare("
    SELECT facultyID, collegeID
    FROM faculty
    WHERE facultyID = ? AND collegeID = ?
");
if (!$checkFaculty) {
    die("Faculty check error: " . $conn->error);
}
$checkFaculty->bind_param("ii", $facultyID, $collegeID);
$checkFaculty->execute();
$faculty = $checkFaculty->get_result()->fetch_assoc();
$checkFaculty->close();

if (!$faculty) {
    header("Location: login.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT electionID, electionName, collegeID, status, showCandidateNames
    FROM election
    WHERE collegeID = ?
    ORDER BY electionID DESC
    LIMIT 1
");
if (!$stmt) {
    die("Election query error: " . $conn->error);
}
$stmt->bind_param("i", $collegeID);
$stmt->execute();
$election = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$election) {
    echo "<script>alert('No election available for your college.'); window.location.href='facultyHomePage.php';</script>";
    exit();
}

if ($election['status'] === 'Nominating') {
    header("Location: facultyNomination.php");
    exit();
}

if ($election['status'] !== 'Voting') {
    echo "<script>alert('No voting session is currently active.'); window.location.href='facultyHomePage.php';</script>";
    exit();
}

$electionID = $election['electionID'];
$showCandidateNames = (int)$election['showCandidateNames'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggleNames'])) {
    $newValue = $showCandidateNames ? 0 : 1;

    $toggleStmt = $conn->prepare("
        UPDATE election
        SET showCandidateNames = ?
        WHERE electionID = ?
    ");
    if (!$toggleStmt) {
        die("Toggle update error: " . $conn->error);
    }
    $toggleStmt->bind_param("ii", $newValue, $electionID);
    if (!$toggleStmt->execute()) {
        die("Toggle execute error: " . $toggleStmt->error);
    }
    $toggleStmt->close();

    header("Location: facultyTabulation.php");
    exit();
}

$positions = [];
$stmt = $conn->prepare("
    SELECT positionID, positionName, winners
    FROM `position`
    WHERE electionID = ?
    ORDER BY positionID ASC
");
if (!$stmt) {
    die("Position query error: " . $conn->error);
}
$stmt->bind_param("i", $electionID);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $positions[] = $row;
}
$stmt->close();

$results = [];

foreach ($positions as $pos) {
    $positionID = $pos['positionID'];
    $positionName = $pos['positionName'];
    $winnerLimit = (int)$pos['winners'];

    $stmt = $conn->prepare("
        SELECT
            n.nominationID,
            s.studentID,
            s.fullName,
            COUNT(v.voteID) AS votes
        FROM nomination n
        INNER JOIN student s ON s.studentID = n.nomineeID
        LEFT JOIN vote v ON v.nominationID = n.nominationID
        WHERE n.electionID = ? AND n.positionID = ? AND (n.status = 'Accepted' OR n.status IS NULL)
        GROUP BY n.nominationID, s.studentID, s.fullName
        ORDER BY votes DESC, s.fullName ASC
    ");
    if (!$stmt) {
        die("Candidate query error: " . $conn->error);
    }
    $stmt->bind_param("ii", $electionID, $positionID);
    $stmt->execute();
    $candidates = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $results[] = [
        'positionID' => $positionID,
        'positionName' => $positionName,
        'winnerLimit' => $winnerLimit,
        'candidates' => $candidates
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Voting - Faculty Tabulation</title>
<style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #d9d9d9;
        overflow: hidden;
    }

    .header {
        width: 100%;
        background: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logout-btn {
        background: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: background 0.3s;
    }

    .logout-btn:hover {
        background: #e6e6e6;
    }

    .container {
        display: flex;
        min-height: calc(100vh - 67px);
    }

    .sidebar {
        width: 220px;
        background-color: #f0f0f0;
        padding: 2rem 1rem;
        flex-shrink: 0;
    }

    .sidebar a {
        display: block;
        padding: 0.65rem 1rem;
        margin-bottom: 0.6rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
    }

    .sidebar a.active {
        background-color: #a6c8ff;
    }

    .main {
        flex: 1;
        padding: 2rem;
        display: flex;
        gap: 1rem;
        overflow-x: auto;
        scroll-snap-type: x mandatory;
    }

    .position-card {
        flex: 0 0 320px;
        background: white;
        border-radius: 1rem;
        padding: 1rem;
        box-shadow: 0 2px 6px rgba(0,0,0,.08);
        scroll-snap-align: start;
        display: flex;
        flex-direction: column;
        max-height: 78vh;
    }

    .position-card h3 {
        margin: 0 0 0.3rem 0;
        color: #4099ff;
        text-align: center;
    }

    .position-sub {
        text-align: center;
        color: #666;
        margin-bottom: 1rem;
        font-size: 0.95rem;
    }

    .candidate-list {
        list-style: none;
        padding: 0;
        margin: 0;
        overflow-y: auto;
        flex: 1;
    }

    .candidate-item {
        padding: 0.85rem 1rem;
        margin-bottom: 0.65rem;
        background: #4099ff;
        color: white;
        border-radius: 0.85rem;
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        align-items: center;
        font-weight: bold;
    }

    .candidate-item.top {
        background: #2f7ad9;
    }

    .candidate-name {
        flex: 1;
        word-break: break-word;
    }

    .candidate-votes {
        white-space: nowrap;
    }

    .empty-text {
        color: #666;
        text-align: center;
        margin-top: 1rem;
    }

    #endVotingBtn,
    #toggleNamesBtn {
        position: fixed;
        bottom: 20px;
        padding: 1rem 1.5rem;
        font-size: 1rem;
        color: white;
        border: none;
        border-radius: 1rem;
        cursor: pointer;
        box-shadow: 0 2px 5px rgba(0,0,0,.2);
    }

    #endVotingBtn {
        left: 255px;
        background: #ff4d4d;
    }

    #endVotingBtn:hover {
        background: #e63939;
    }

    #toggleNamesBtn {
        left: 465px;
        background: #4099ff;
    }

    #toggleNamesBtn:hover {
        background: #2f7ad9;
    }

    @media (max-width: 900px) {
        .container {
            flex-direction: column;
        }

        .sidebar {
            width: 100%;
            padding: 1rem;
            display: flex;
            gap: 0.5rem;
            overflow-x: auto;
        }

        .sidebar a {
            white-space: nowrap;
            margin-bottom: 0;
        }

        .main {
            padding: 1rem;
        }

        #endVotingBtn {
            left: 20px;
            bottom: 20px;
        }

        #toggleNamesBtn {
            left: 20px;
            bottom: 85px;
        }
    }
</style>
</head>
<body>
<div class="header">
    <div>SMC Council Voting</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>

<div class="container">
    <div class="sidebar">
        <a href="facultyHomePage.php">Home</a>
        <a href="facultyElection.php">Election</a>
        <a href="#" class="active">Winners</a>
        <a href="#">College Officers</a>
    </div>

    <div class="main">
        <?php foreach ($results as $res): ?>
            <div class="position-card">
                <h3><?= htmlspecialchars($res['positionName']) ?></h3>
                <div class="position-sub">Winners needed: <?= (int)$res['winnerLimit'] ?></div>

                <?php if (!empty($res['candidates'])): ?>
                    <ul class="candidate-list">
                        <?php foreach ($res['candidates'] as $index => $cand): ?>
                            <li class="candidate-item <?= $index < $res['winnerLimit'] ? 'top' : '' ?>">
                                <span class="candidate-name">
                                    Rank <?= $index + 1 ?> - <?= htmlspecialchars($cand['fullName']) ?>
                                </span>
                                <span class="candidate-votes"><?= (int)$cand['votes'] ?> vote(s)</span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-text">No candidates yet.</div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<button id="endVotingBtn" onclick="endVoting()">End Voting Session</button>

<form method="POST">
    <button type="submit" name="toggleNames" id="toggleNamesBtn">
        <?= $showCandidateNames ? 'Hide Names for Students' : 'Show Names for Students' ?>
    </button>
</form>

<script>
function endVoting() {
    if (confirm("Are you sure you want to end this voting session?")) {
        window.location.href = "endVoting.php?electionID=<?= (int)$electionID ?>";
    }
}
</script>
</body>
</html>