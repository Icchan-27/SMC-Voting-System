<?php
session_start();
include 'connect.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idNumber = $_POST['idNumber'];
    $password = $_POST['password'];

    $sqlStudent = "SELECT * FROM student WHERE idNumber = ? AND password = ?";
    $stmtStudent = $conn->prepare($sqlStudent);
    $stmtStudent->bind_param("ss", $idNumber, $password);
    $stmtStudent->execute();
    $resultStudent = $stmtStudent->get_result();

    if ($resultStudent->num_rows > 0) {
        $student = $resultStudent->fetch_assoc();
        $_SESSION['idNumber'] = $student['idNumber'];
        $_SESSION['student_id'] = $student['student_id'];
        $_SESSION['college_id'] = $student['college_id'];
        header("Location: studentHomePage.php");
        exit();
    }

    $sqlFaculty = "SELECT * FROM faculty WHERE id_number = ? AND password = ?";
    $stmtFaculty = $conn->prepare($sqlFaculty);
    $stmtFaculty->bind_param("ss", $idNumber, $password);
    $stmtFaculty->execute();
    $resultFaculty = $stmtFaculty->get_result();

    if ($resultFaculty->num_rows > 0) {
        $faculty = $resultFaculty->fetch_assoc();
        $_SESSION['idNumber'] = $faculty['id_number'];
        $_SESSION['faculty_id'] = $faculty['faculty_id'];
        $_SESSION['college_id'] = $faculty['college_id'];
        header("Location: facultyHomePage.php");
        exit();
    }

    $error = "Incorrect ID Number or password.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Anton&display=swap');
    :root { font-size: 16px; }
    html, body {
        margin: 0;
        background-color: #ccc;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        font-family: sans-serif;
    }
    .square {
        width: 100%;
        height: 4rem;
        background-color: #4099ff;
        font-family: 'Anton', sans-serif;
        font-size: 2rem;
        color: white;
        display: flex;
        align-items: center;
        padding-left: 1rem;
    }
    .content {
        flex: 1;
        display: flex;
        justify-content: flex-end;
        align-items: stretch;
    }
    .login {
        flex: 0 1 25%;
        max-width: 400px;
        min-width: 280px;
        background: white;
        border-radius: 1rem 0 0 1rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 2rem 1.5rem;
    }
    .login h2 {
        font-family: 'Anton', sans-serif;
        font-size: 1.75rem;
        color: #4099ff;
        margin-bottom: 1.25rem;
        width: 100%;
        text-align: left;
    }
    .login input {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #ccc;
        border-radius: 2rem;
        font-size: 1rem;
        text-align: center;
        margin-bottom: 1rem;
    }
    .login button {
        width: 100%;
        padding: 0.85rem;
        border: none;
        border-radius: 2rem;
        background-color: #4099ff;
        color: white;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    .login button:hover { background-color: #3277cc; }
    .error {
        color: red;
        font-size: 0.9rem;
        margin: -0.5rem 0 1rem 0;
        width: 100%;
        text-align: center;
    }
</style>
</head>
<body>
<div class="square">MySMC Election</div>
<div class="content">
    <div class="login">
        <h2>Login</h2>
        <form method="POST">
            <input type="text" name="idNumber" placeholder="ID Number" required>
            <input type="password" name="password" placeholder="Password" required>
            <?php if (!empty($error)) { ?>
                <p class="error"><?php echo $error; ?></p>
            <?php } ?>
            <button type="submit">Login</button>
        </form>
    </div>
</div>
</body>
</html>