<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$elections = [];
$studentCollege = $_SESSION['college_id'];
$stmt = $conn->prepare("SELECT election_id, electionName, organization, college_id FROM elections WHERE status = 'Ongoing' AND college_id = ?");
$stmt->bind_param("i", $studentCollege);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo "<script>alert('No ongoing election within your college.');window.location.href='studentHomePage.php';</script>";
    exit();
}
while ($row = $result->fetch_assoc()) $elections[] = $row;
$stmt->close();

$electionId = $elections[0]['election_id'];
$electionCollege = $elections[0]['college_id'];
$userId = $_SESSION['student_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['candidate_id'], $_POST['position'])) {
    $candidateId = $_POST['candidate_id'];
    $positionName = $_POST['position'];

    $stmt = $conn->prepare("
        SELECT ep.election_position_id, sp.student_position_name
        FROM election_position ep 
        INNER JOIN student_positions sp ON sp.student_position_id = ep.student_position_id 
        WHERE sp.student_position_name = ? AND ep.election_id = ?
    ");
    $stmt->bind_param("si", $positionName, $electionId);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $electionPos = $row['election_position_id'];
        $posName = $row['student_position_name'];

        $stmt = $conn->prepare("SELECT yearLevel FROM student WHERE student_id=?");
        $stmt->bind_param("i", $candidateId);
        $stmt->execute();
        $candRes = $stmt->get_result();
        $candYear = $candRes->fetch_assoc()['yearLevel'];

        $stmt = $conn->prepare("SELECT yearLevel FROM student WHERE student_id=?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $nomRes = $stmt->get_result();
        $nomYear = $nomRes->fetch_assoc()['yearLevel'];

        $allowed = false;

        if (stripos($posName, 'Year') !== false) {
            if (strpos($posName, $candYear) !== false && strpos($posName, $nomYear) !== false) {
                $allowed = true;
            }
        } else {
            $allowed = true;
        }

        if ($allowed) {
            $stmt = $conn->prepare("SELECT nomination_id FROM nomination WHERE election_position_id=? AND candidate_id=?");
            $stmt->bind_param("ii", $electionPos, $candidateId);
            $stmt->execute();
            $res = $stmt->get_result();
            if ($res->num_rows === 0) {
                $stmt = $conn->prepare("INSERT INTO nomination (election_position_id, candidate_id) VALUES (?, ?)");
                $stmt->bind_param("ii", $electionPos, $candidateId);
                $stmt->execute();
                $nominationId = $stmt->insert_id;
            } else {
                $row = $res->fetch_assoc();
                $nominationId = $row['nomination_id'];
            }

            $stmt = $conn->prepare("SELECT * FROM nomination_nominators WHERE nomination_id=? AND nominator_id=?");
            $stmt->bind_param("ii", $nominationId, $userId);
            $stmt->execute();
            if ($stmt->get_result()->num_rows === 0) {
                $stmt = $conn->prepare("INSERT INTO nomination_nominators (nomination_id, nominator_id) VALUES (?, ?)");
                $stmt->bind_param("ii", $nominationId, $userId);
                $stmt->execute();
            }
        } else {
            echo "<script>alert('Only students of the correct year level can nominate and be nominated for this position.');</script>";
        }
    }
}

if (isset($_POST['confirm_end_nomination'])) {
    $stmt = $conn->prepare("
        SELECT ep.election_position_id, ep.num_winners, sp.student_position_name
        FROM election_position ep
        INNER JOIN student_positions sp ON sp.student_position_id = ep.student_position_id
        WHERE ep.election_id = ?
    ");
    $stmt->bind_param("i", $electionId);
    $stmt->execute();
    $positionsRes = $stmt->get_result();

    $valid = true;
    $errorMessage = "";

    while ($pos = $positionsRes->fetch_assoc()) {
        $posId = $pos['election_position_id'];
        $numWinners = $pos['num_winners'];
        $posName = $pos['student_position_name'];

        $stmt2 = $conn->prepare("SELECT COUNT(DISTINCT candidate_id) as total FROM nomination WHERE election_position_id=?");
        $stmt2->bind_param("i", $posId);
        $stmt2->execute();
        $countRes = $stmt2->get_result()->fetch_assoc();
        $totalNoms = $countRes['total'];

    if ($totalNoms < $numWinners) {
        $valid = false;
        $errorMessage .= "Position $posName requires at least $numWinners nominees, but only $totalNoms are nominated.\n";
    }
    }

    if ($valid) {
        $stmt = $conn->prepare("SELECT * FROM end_nomination WHERE election_id=? AND student_id=?");
        $stmt->bind_param("ii", $electionId, $userId);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            $stmt = $conn->prepare("INSERT INTO end_nomination (election_id, student_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $electionId, $userId);
            $stmt->execute();
        }
    } else {
        echo "<script>alert(" . json_encode($errorMessage) . ");</script>";
    }
    }

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM end_nomination WHERE election_id=?");
$stmt->bind_param("i", $electionId);
$stmt->execute();
$totalEnd = $stmt->get_result()->fetch_assoc()['total'];

if ($totalEnd >= 3) {
    header("Location: studentVoting.php");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM end_nomination WHERE election_id=? AND student_id=?");
$stmt->bind_param("ii", $electionId, $userId);
$stmt->execute();
$hasConfirmed = $stmt->get_result()->num_rows > 0;

$positions = [];
$posStmt = $conn->prepare("SELECT sp.student_position_name FROM election_position ep INNER JOIN student_positions sp ON sp.student_position_id = ep.student_position_id WHERE ep.election_id = ?");
$posStmt->bind_param("i", $electionId);
$posStmt->execute();
$res = $posStmt->get_result();
while ($row = $res->fetch_assoc()) $positions[] = $row['student_position_name'];
$posStmt->close();

$students = [];
$stmt = $conn->prepare("SELECT student_id, idNumber, firstName, middleName, lastName, yearLevel FROM student WHERE college_id=?");
$stmt->bind_param("i", $electionCollege);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $students[] = $row;
$stmt->close();

$history = [];
$stmt = $conn->prepare("SELECT n.nomination_id, s.firstName, s.middleName, s.lastName, sp.student_position_name FROM nomination n INNER JOIN student s ON s.student_id = n.candidate_id INNER JOIN election_position ep ON ep.election_position_id = n.election_position_id INNER JOIN student_positions sp ON sp.student_position_id = ep.student_position_id WHERE ep.election_id=?");
$stmt->bind_param("i", $electionId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $history[] = $row;
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SMC Council Voting</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #d9d9d9;
    overflow: hidden;
}

.header {
    width: 100%;
    background: #4099ff;
    color: white;
    padding: 1rem 2rem;
    font-size: 1.5rem;
    font-weight: bold;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
}

.logout-btn {
    background: white;
    color: #4099ff;
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 1rem;
    font-size: 1rem;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    transition: background 0.3s;
}

.logout-btn:hover {
    background: #e6e6e6;
}

.container {
    display: flex;
    height: calc(100vh - 60px);
}

.sidebar {
    width: 220px;
    background: #f0f0f0;
    padding: 2rem 1rem;
    box-sizing: border-box;
}

.sidebar a {
    display: block;
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    text-decoration: none;
    color: black;
    border-radius: 1rem;
}

.sidebar a.active {
    background: #a6c8ff;
}

.main {
    flex: 1;
    padding: 2rem;
    box-sizing: border-box;
    display: flex;
    gap: 2rem;
}

.profile {
    flex: 1;
    background: #a6c8ff;
    padding: 1rem;
    border-radius: 1rem;
    color: white;
    max-height: 500px;
    overflow-y: auto;
}

.candidate-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.candidate-item {
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    background: #4099ff;
    border-radius: 0.75rem;
    cursor: pointer;
    transition: background 0.2s;
}

.candidate-item:hover {
    background: #2f7ad9;
}

.history {
    flex: 2;
    background: white;
    border-radius: 1rem;
    padding: 1rem;
    box-sizing: border-box;
    overflow-y: auto;
    max-height: 500px;
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.95rem;
}

th,
td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #eee;
    text-align: left;
}

th {
    background: #d0e4ff;
}

.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,.5);
    justify-content: center;
    align-items: center;
}

.modal-content {
    background: white;
    padding: 20px;
    border-radius: 1rem;
    width: 320px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,.3);
}

.modal-content h3 {
    margin-bottom: 1rem;
}

.modal-content select,
.modal-content button {
    margin-top: 10px;
    padding: 8px;
    width: 100%;
    border-radius: 0.5rem;
    border: 1px solid #ccc;
    font-size: 1rem;
}

.modal-content button {
    background: #4099ff;
    color: white;
    border: none;
    cursor: pointer;
}

.modal-content button:hover {
    background: #2f7ad9;
}

#endNominationBtn {
    position: fixed;
    bottom: 20px;
    right: 20px;
    padding: 1rem 1.5rem;
    font-size: 1rem;
    background: #4099ff;
    color: white;
    border: none;
    border-radius: 1rem;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0,0,0,.2);
}

#endNominationBtn:hover {
    background: #2f7ad9;
}

#endNominationBtn:disabled {
    background: #ccc;
    cursor: not-allowed;
}

#searchBar {
    width: 70%;
    padding: 0.5rem;
    border-radius: 0.5rem;
    border: 1px solid #ccc;
    margin-bottom: 1rem;
}

#yearFilter {
    padding: 0.5rem;
    border-radius: 0.5rem;
    border: 1px solid #ccc;
    margin-left: 0.5rem;
}

.filter-container {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1rem;
}
</style>
</head>
<body>
<div class="header">
    <div>SMC Council Voting</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>
<div class="container">
    <div class="sidebar">
        <a href="studentHomePage.php">Home</a>
        <a href="#" class="active">Election</a>
        <a href="#">Winners</a>
        <a href="#">College Officers</a>
    </div>
    <div class="main">
        <div class="profile">
            <?php if(!$hasConfirmed && $totalEnd < 3): ?>
            <div class="filter-container">
                <input type="text" id="searchBar" placeholder="Search students...">
                <select id="yearFilter">
                    <option value="">All Years</option>
                    <option value="1st">1st Year</option>
                    <option value="2nd">2nd Year</option>
                    <option value="3rd">3rd Year</option>
                    <option value="4th">4th Year</option>
                </select>
            </div>
            <ul class="candidate-list" id="candidateList">
                <?php foreach($students as $student): ?>
                <li class="candidate-item" data-id="<?= $student['student_id']?>" data-name="<?= htmlspecialchars($student['firstName'].' '.$student['middleName'].' '.$student['lastName']) ?>" data-year="<?= $student['yearLevel'] ?>">
                    <?= htmlspecialchars($student['firstName'].' '.$student['middleName'].' '.$student['lastName'])?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php else: ?>
            <p>You can no longer nominate candidates.</p>
            <?php endif; ?>
        </div>
        <div class="history">
            <table>
                <thead>
                    <tr><th>Name</th><th>Position</th><th>Position</th></tr>
                </thead>
                <tbody>
                    <?php foreach($history as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['firstName'].' '.$row['middleName'].' '.$row['lastName']) ?></td>
                        <td><?= htmlspecialchars($row['student_position_name']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<form method="POST">
    <button id="endNominationBtn" name="confirm_end_nomination" <?= ($totalEnd>=3 || $hasConfirmed)?'disabled':''; ?>>
        <?= $hasConfirmed ? "You already confirmed ($totalEnd/3)" : "End Nomination ($totalEnd/3)" ?>
    </button>
</form>
<div class="modal" id="nominateModal">
    <div class="modal-content">
        <form method="POST">
            <h3 id="modalTitle"></h3>
            <input type="hidden" name="candidate_id" id="candidateIdInput">
            <select name="position" id="positionSelect">
                <option value="">Select Position</option>
                <?php foreach($positions as $pos): ?>
                    <option value="<?= htmlspecialchars($pos) ?>"><?= htmlspecialchars($pos) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Nominate</button>
        </form>
    </div>
</div>
<script>
const modal=document.getElementById("nominateModal")
const modalTitle=document.getElementById("modalTitle")
const candidateIdInput=document.getElementById("candidateIdInput")
document.querySelectorAll(".candidate-item").forEach(item=>{
    item.addEventListener("click",()=>{
        modalTitle.textContent="Nominate "+item.getAttribute("data-name")
        candidateIdInput.value=item.getAttribute("data-id")
        modal.style.display="flex"
    })
})
window.addEventListener("click",e=>{if(e.target===modal) modal.style.display="none"})
const searchBar=document.getElementById("searchBar")
const yearFilter=document.getElementById("yearFilter")
const candidateList=document.getElementById("candidateList")
searchBar.addEventListener("input",filterList)
yearFilter.addEventListener("change",filterList)
function filterList(){
    const search=searchBar.value.toLowerCase()
    const year=yearFilter.value
    document.querySelectorAll("#candidateList .candidate-item").forEach(item=>{
        const name=item.getAttribute("data-name").toLowerCase()
        const itemYear=item.getAttribute("data-year")
        const matchName=name.includes(search)
        const matchYear=year===""||year===itemYear
        item.style.display=(matchName&&matchYear)?"block":"none"
    })
}
</script>
</body>
</html>