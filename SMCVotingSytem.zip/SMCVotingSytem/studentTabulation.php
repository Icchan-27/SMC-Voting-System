<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['student_id']) && !isset($_SESSION['faculty_id'])) {
    header("Location: login.php");
    exit();
}

$elections = [];

if (isset($_SESSION['student_id'])) {
    $studentCollege = $_SESSION['college_id'];
    $stmt = $conn->prepare("SELECT election_id, electionName, organization, college_id
                            FROM elections
                            WHERE status = 'Ongoing'
                            AND college_id = ?");
    $stmt->bind_param("i", $studentCollege);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        echo "<script>
                alert('No ongoing election within your college.');
                window.location.href = 'studentHomePage.php';
              </script>";
        exit();
    }
    while ($row = $result->fetch_assoc()) $elections[] = $row;
    $stmt->close();
}

if (isset($_SESSION['faculty_id'])) {
    $stmt = $conn->prepare("SELECT election_id, electionName, organization, college_id
                            FROM elections
                            WHERE status = 'Ongoing'");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        echo "<script>
                alert('No ongoing elections available.');
                window.location.href = 'facultyHomePage.php';
              </script>";
        exit();
    }
    while ($row = $result->fetch_assoc()) $elections[] = $row;
    $stmt->close();
}

$electionId = $elections[0]['election_id'];
$electionCollege = $elections[0]['college_id'];

$positions = [];
$stmt = $conn->prepare("
    SELECT ep.election_position_id, sp.student_position_name
    FROM election_position ep
    INNER JOIN student_positions sp ON sp.student_position_id = ep.student_position_id
    WHERE ep.election_id = ?");
$stmt->bind_param("i", $electionId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $positions[] = $row;
$stmt->close();

$results = [];
foreach ($positions as $pos) {
    $posId = $pos['election_position_id'];
    $posName = $pos['student_position_name'];

    $stmt = $conn->prepare("
        SELECT s.firstName, s.middleName, s.lastName,
               COUNT(v.vote_id) as votes
        FROM nomination n
        INNER JOIN student s ON s.student_id = n.candidate_id
        LEFT JOIN votes v ON v.nomination_id = n.nomination_id
        WHERE n.election_position_id = ?
        GROUP BY n.nomination_id, s.firstName, s.middleName, s.lastName
        ORDER BY votes DESC
    ");
    $stmt->bind_param("i", $posId);
    $stmt->execute();
    $candidates = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $results[] = [
        'position' => $posName,
        'candidates' => $candidates
    ];
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SMC Council Voting - Results</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #d9d9d9;
    overflow: hidden;
}

.header {
    width: 100%;
    background: #4099ff;
    color: white;
    padding: 1rem 2rem;
    font-size: 1.5rem;
    font-weight: bold;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
}

.logout-btn {
    background: white;
    color: #4099ff;
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 1rem;
    font-size: 1rem;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    transition: background 0.3s;
}

.logout-btn:hover {
    background: #e6e6e6;
}

.container {
    display: flex;
    height: calc(100vh - 60px);
}

.sidebar {
    width: 220px;
    background: #f0f0f0;
    padding: 2rem 1rem;
    box-sizing: border-box;
}

.sidebar a {
    display: block;
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    text-decoration: none;
    color: black;
    border-radius: 1rem;
}

.sidebar a.active {
    background: #a6c8ff;
}

.main {
    flex: 1;
    padding: 2rem;
    box-sizing: border-box;
    overflow-x: auto;
    display: flex;
    gap: 1rem;
    scroll-snap-type: x mandatory;
}

.position-card {
    flex: 0 0 300px;
    background: white;
    border-radius: 1rem;
    padding: 1rem;
    box-shadow: 0 2px 5px rgba(0,0,0,.1);
    scroll-snap-align: start;
}

.position-card h3 {
    margin-top: 0;
    color: #4099ff;
    text-align: center;
}

.candidate-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.candidate-item {
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    background: #4099ff;
    color: white;
    border-radius: 0.75rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: bold;
}
</style>
</head>
<body>
<div class="header">
    <div>SMC Council Voting</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>
<div class="container">
    <div class="sidebar">
        <a href="studentHomePage.php">Home</a>
        <a href="#" class="active">Election</a>
        <a href="#">Winners</a>
        <a href="#">College Officers</a>
    </div>
    <div class="main">
        <?php foreach ($results as $res): ?>
            <div class="position-card">
                <h3><?= htmlspecialchars($res['position']) ?></h3>
                <ul class="candidate-list">
                    <?php foreach ($res['candidates'] as $cand): ?>
                        <li class="candidate-item">
                            <span><?= htmlspecialchars($cand['firstName'].' '.$cand['middleName'].' '.$cand['lastName']) ?></span>
                            <span><?= $cand['votes'] ?> votes</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>