<?php
session_start();
include 'connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['studentID'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

$studentID = (int) $_SESSION['studentID'];

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (
    !is_array($data) ||
    !isset($data['nominations']) ||
    !is_array($data['nominations']) ||
    count($data['nominations']) === 0
) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid data']);
    exit();
}

$nominations = array_values(array_unique(array_map('intval', $data['nominations'])));

if (count($nominations) === 0) {
    http_response_code(400);
    echo json_encode(['error' => 'No nominations provided']);
    exit();
}

$in = implode(',', $nominations);

$sql = "
    SELECT DISTINCT n.electionID
    FROM nomination n
    WHERE n.nominationID IN ($in)
";
$res = $conn->query($sql);

if (!$res) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error (fetch election)', 'mysql_error' => $conn->error]);
    exit();
}

$electionIds = [];
while ($row = $res->fetch_assoc()) {
    $electionIds[] = (int)$row['electionID'];
}

if (count($electionIds) === 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Nominations not found']);
    exit();
}

if (count($electionIds) > 1) {
    http_response_code(400);
    echo json_encode(['error' => 'Selected nominations belong to multiple elections']);
    exit();
}

$electionID = $electionIds[0];

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM vote
    WHERE studentID = ? AND electionID = ?
");
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Prepare failed', 'mysql_error' => $conn->error]);
    exit();
}
$stmt->bind_param("ii", $studentID, $electionID);
$stmt->execute();
$already = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ((int)$already['total'] > 0) {
    http_response_code(409);
    echo json_encode(['error' => 'You have already voted in this election']);
    exit();
}

$insertStmt = $conn->prepare("
    INSERT INTO vote (electionID, positionID, studentID, nominationID, voteDate)
    VALUES (?, ?, ?, ?, NOW())
");
if (!$insertStmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Prepare failed', 'mysql_error' => $conn->error]);
    exit();
}

foreach ($nominations as $nominationID) {
    $stmt = $conn->prepare("
        SELECT positionID, electionID
        FROM nomination
        WHERE nominationID = ?
    ");
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['error' => 'Prepare failed', 'mysql_error' => $conn->error]);
        exit();
    }

    $stmt->bind_param("i", $nominationID);
    $stmt->execute();
    $nomination = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$nomination) {
        $insertStmt->close();
        http_response_code(400);
        echo json_encode(['error' => 'Invalid nomination ID: ' . $nominationID]);
        exit();
    }

    $positionID = (int)$nomination['positionID'];
    $nomElectionID = (int)$nomination['electionID'];

    if ($nomElectionID !== $electionID) {
        $insertStmt->close();
        http_response_code(400);
        echo json_encode(['error' => 'Nomination election mismatch']);
        exit();
    }

    $insertStmt->bind_param("iiii", $electionID, $positionID, $studentID, $nominationID);

    if (!$insertStmt->execute()) {
        $insertStmt->close();
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save vote', 'mysql_error' => $insertStmt->error]);
        exit();
    }
}

$insertStmt->close();

echo json_encode([
    'success' => true,
    'message' => 'Votes submitted successfully'
]);
?>