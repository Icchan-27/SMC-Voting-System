<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['studentID']) || empty($_SESSION['isOfficer'])) {
    header("Location: login.php");
    exit();
}

$studentID = $_SESSION['studentID'];

$stmt = $conn->prepare("
    SELECT studentID, collegeID
    FROM student
    WHERE studentID = ?
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $studentID);
$stmt->execute();
$studentData = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$studentData) {
    header("Location: login.php");
    exit();
}

$currentCollegeID = $studentData['collegeID'];

$stmt = $conn->prepare("
    SELECT electionID, electionName, collegeID, status
    FROM election
    WHERE collegeID = ?
    ORDER BY electionID DESC
    LIMIT 1
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $currentCollegeID);
$stmt->execute();
$electionResult = $stmt->get_result();

if ($electionResult->num_rows === 0) {
    echo "<script>alert('No election available.'); window.location.href='studentHomePage.php';</script>";
    exit();
}

$election = $electionResult->fetch_assoc();
$stmt->close();

if ($election['status'] === 'Voting') {
    header("Location: studentVoting.php");
    exit();
}

if ($election['status'] !== 'Nomination' && $election['status'] !== 'Nominating') {
    echo "<script>alert('No nomination phase currently available.'); window.location.href='studentHomePage.php';</script>";
    exit();
}

$electionID = $election['electionID'];
$electionCollegeID = $election['collegeID'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nomineeID'], $_POST['positionID'])) {
    $nomineeID = (int) $_POST['nomineeID'];
    $positionID = (int) $_POST['positionID'];

    $stmt = $conn->prepare("
        SELECT positionID
        FROM `position`
        WHERE positionID = ? AND electionID = ?
    ");
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }
    $stmt->bind_param("ii", $positionID, $electionID);
    $stmt->execute();
    $validPosition = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$validPosition) {
        echo "<script>alert('Invalid position for this election.'); window.location.href='nomination.php';</script>";
        exit();
    }

    $stmt = $conn->prepare("
        SELECT studentID
        FROM student
        WHERE studentID = ? AND collegeID = ?
    ");
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }
    $stmt->bind_param("ii", $nomineeID, $electionCollegeID);
    $stmt->execute();
    $validNominee = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$validNominee) {
        echo "<script>alert('Invalid nominee.'); window.location.href='nomination.php';</script>";
        exit();
    }

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM nomination
        WHERE electionID = ? AND nominatorID = ? AND nomineeID = ? AND positionID = ?
    ");
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }
    $stmt->bind_param("iiii", $electionID, $studentID, $nomineeID, $positionID);
    $stmt->execute();
    $duplicate = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($duplicate['total'] > 0) {
        echo "<script>alert('You already nominated this person for this position.'); window.location.href='nomination.php';</script>";
        exit();
    }

    $stmt = $conn->prepare("
        INSERT INTO nomination (electionID, nominatorID, nomineeID, positionID)
        VALUES (?, ?, ?, ?)
    ");
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }
    $stmt->bind_param("iiii", $electionID, $studentID, $nomineeID, $positionID);

    if (!$stmt->execute()) {
        die("Nomination insert error: " . $stmt->error);
    }

    $stmt->close();

    header("Location: nomination.php?success=1");
    exit();
}

$students = [];
$stmt = $conn->prepare("
    SELECT studentID, idNumber, fullName, yearLevel
    FROM student
    WHERE collegeID = ?
    ORDER BY fullName ASC
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $electionCollegeID);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $students[] = $row;
}
$stmt->close();

$positions = [];
$stmt = $conn->prepare("
    SELECT positionID, positionName
    FROM `position`
    WHERE electionID = ?
    ORDER BY positionName ASC
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $electionID);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $positions[] = $row;
}
$stmt->close();

$history = [];
$stmt = $conn->prepare("
    SELECT
        n.nominationID,
        s.fullName,
        p.positionName
    FROM nomination n
    INNER JOIN student s ON s.studentID = n.nomineeID
    INNER JOIN `position` p ON p.positionID = n.positionID
    WHERE p.electionID = ?
    ORDER BY n.nominationID DESC
");
if (!$stmt) {
    die("SQL Error: " . $conn->error);
}
$stmt->bind_param("i", $electionID);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $history[] = $row;
}
$stmt->close();

$success = isset($_GET['success']) && $_GET['success'] == '1';
$updated = isset($_GET['updated']) && $_GET['updated'] == '1';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Nomination</title>
<style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
    }

    .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logout-btn {
        background: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: background 0.3s;
    }

    .logout-btn:hover {
        background: #e6e6e6;
    }

    .container {
        display: flex;
        min-height: calc(100vh - 67px);
    }

    .sidebar {
        width: 220px;
        background-color: #f0f0f0;
        padding: 2rem 1rem;
    }

    .sidebar a {
        display: block;
        padding: 0.65rem 1rem;
        margin-bottom: 0.6rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
    }

    .sidebar a.active {
        background-color: #a6c8ff;
    }

    .main {
        flex: 1;
        padding: 2rem;
        display: flex;
        gap: 2rem;
        align-items: flex-start;
    }

    .profile {
        flex: 1.15;
        background-color: #a6c8ff;
        padding: 1.25rem;
        border-radius: 1rem;
        color: white;
        max-height: 78vh;
        overflow-y: auto;
    }

    .history {
        flex: 1;
        background-color: white;
        border-radius: 1rem;
        overflow: hidden;
        max-height: 78vh;
        overflow-y: auto;
    }

    .search-wrap {
        display: flex;
        gap: 0.75rem;
        margin-bottom: 1rem;
        padding-bottom: 0.35rem;
    }

    #searchInput {
        flex: 1;
        min-width: 0;
        padding: 0.85rem 1rem;
        border: none;
        border-radius: 0.8rem;
        font-size: 1rem;
        outline: none;
    }

    #searchBtn {
        padding: 0.85rem 1.2rem;
        border: none;
        border-radius: 0.8rem;
        background-color: white;
        color: #4099ff;
        font-weight: bold;
        cursor: pointer;
    }

    #searchBtn:hover {
        background-color: #eef5ff;
    }

    .candidate-list {
        list-style: none;
        padding: 0;
        margin: 0;
        padding-bottom: 0.8rem;
    }

    .candidate-item {
        padding: 0.9rem 1rem;
        margin-bottom: 0.75rem;
        background: #4099ff;
        border-radius: 0.75rem;
        cursor: pointer;
        transition: background 0.2s;
    }

    .candidate-item:hover {
        background: #2f7ad9;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    table th, table td {
        padding: 0.85rem 1rem;
        text-align: left;
        border-bottom: 1px solid #eee;
        vertical-align: top;
    }

    table th {
        background-color: #d0e4ff;
        position: sticky;
        top: 0;
    }

    .action-form {
        display: inline-block;
        margin-right: 4px;
    }

    .accept-btn, .reject-btn, .end-btn {
        border: none;
        padding: 8px 12px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: bold;
    }

    .accept-btn {
        background: #4caf50;
        color: white;
    }

    .reject-btn {
        background: #f44336;
        color: white;
    }

    .end-btn {
        position: fixed;
        right: 24px;
        bottom: 24px;
        background: #4099ff;
        color: white;
        padding: 12px 18px;
        border-radius: 12px;
    }

    .status-pending {
        color: #ff9800;
        font-weight: bold;
    }

    .status-accepted {
        color: #4caf50;
        font-weight: bold;
    }

    .status-rejected {
        color: #f44336;
        font-weight: bold;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        padding: 1rem;
    }

    .modal-content {
        background: white;
        padding: 20px;
        border-radius: 1rem;
        width: 340px;
        text-align: center;
    }

    .modal-content h3 {
        margin-bottom: 1rem;
        color: #222;
    }

    .modal-content select,
    .modal-content button {
        margin-top: 10px;
        padding: 10px;
        width: 100%;
        border-radius: 0.5rem;
        border: 1px solid #ccc;
    }

    .modal-content button {
        background-color: #4099ff;
        color: white;
        border: none;
        cursor: pointer;
    }

    @media (max-width: 900px) {
        .container {
            flex-direction: column;
        }

        .sidebar {
            width: 100%;
            padding: 1rem;
            display: flex;
            gap: 0.5rem;
            overflow-x: auto;
        }

        .sidebar a {
            white-space: nowrap;
            margin-bottom: 0;
        }

        .main {
            flex-direction: column;
        }

        .profile,
        .history {
            width: 100%;
            max-height: none;
        }
    }
</style>
</head>
<body>
    <div class="header">
        <div>SMC Council Nomination</div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="container">
        <div class="sidebar">
            <a href="studentHomePage.php">Home</a>
            <a href="#" class="active" class="active">Election</a>
            <a href="studentTabulation.php">Winners</a>
            <a href="electionWinners.php">College Officers</a>
        </div>

        <div class="main">
            <div class="profile">
                <div class="search-wrap">
                    <input type="text" id="searchInput" placeholder="Search candidate...">
                    <button type="button" id="searchBtn">Search</button>
                </div>

                <ul class="candidate-list" id="candidateList">
                    <?php foreach ($students as $student): ?>
                    <li class="candidate-item"
                        data-id="<?= (int)$student['studentID'] ?>"
                        data-name="<?= htmlspecialchars($student['fullName']) ?>">
                        <?= htmlspecialchars($student['fullName']) ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="history">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['fullName']) ?></td>
                            <td><?= htmlspecialchars($row['positionName']) ?></td>
                            <td class="status-<?= strtolower(trim(htmlspecialchars($row['status'] ?? 'Pending'))) ?>">
                                <?= htmlspecialchars($row['status'] ?? 'Pending') ?>
                            </td>
                            <td>
                                <?php if (strtolower(trim($row['status'] ?? 'Pending')) === 'pending'): ?>
                                    <form method="POST" class="action-form">
                                        <button type="submit" name="acceptNominee" value="<?= (int)$row['nominationID'] ?>" class="accept-btn">Accept</button>
                                    </form>
                                    <form method="POST" class="action-form">
                                        <button type="submit" name="rejectNominee" value="<?= (int)$row['nominationID'] ?>" class="reject-btn">Reject</button>
                                    </form>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <form method="POST">
        <button type="submit" name="endNomination" value="1" class="end-btn">End Nomination</button>
    </form>

    <div class="modal" id="nominateModal">
        <div class="modal-content">
            <h3 id="modalTitle"></h3>

            <form method="POST">
                <input type="hidden" name="nomineeID" id="nomineeIDInput">

                <select id="positionSelect" name="positionID" required>
                    <option value="">Select Position</option>
                    <?php foreach ($positions as $position): ?>
                    <option value="<?= (int)$position['positionID'] ?>">
                        <?= htmlspecialchars($position['positionName']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit">Nominate</button>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById("nominateModal");
        const modalTitle = document.getElementById("modalTitle");
        const positionSelect = document.getElementById("positionSelect");
        const nomineeIDInput = document.getElementById("nomineeIDInput");
        const searchInput = document.getElementById("searchInput");
        const searchBtn = document.getElementById("searchBtn");

        document.querySelectorAll(".candidate-item").forEach(item => {
            item.addEventListener("click", () => {
                nomineeIDInput.value = item.getAttribute("data-id");
                modalTitle.textContent = "Nominate " + item.getAttribute("data-name");
                positionSelect.value = "";
                modal.style.display = "flex";
            });
        });

        function filterCandidates() {
            const value = searchInput.value.toLowerCase();
            document.querySelectorAll(".candidate-item").forEach(item => {
                const name = item.getAttribute("data-name").toLowerCase();
                item.style.display = name.includes(value) ? "block" : "none";
            });
        }

        searchBtn.addEventListener("click", filterCandidates);
        searchInput.addEventListener("keyup", filterCandidates);

        window.addEventListener("click", e => {
            if (e.target === modal) {
                modal.style.display = "none";
            }
        });

        <?php if ($success): ?>
        alert("Nomination submitted successfully.");
        <?php endif; ?>

        <?php if ($updated): ?>
        alert("Nomination updated successfully.");
        <?php endif; ?>
    </script>
</body>
</html>