<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['facultyID'])) {
    header("Location: login.php");
    exit();
}

$facultyID = $_SESSION['facultyID'];

$stmt = $conn->prepare("
    SELECT f.facultyID, f.IDnumber, f.fullName, f.userName, f.collegeID, c.collegeName
    FROM faculty f
    LEFT JOIN college c ON f.collegeID = c.collegeID
    WHERE f.facultyID = ?
");

if (!$stmt) {
    die("Faculty query error: " . $conn->error);
}

$stmt->bind_param("i", $facultyID);
$stmt->execute();
$result = $stmt->get_result();
$faculty = $result->fetch_assoc();

if (!$faculty) {
    die("Faculty record not found.");
}

$collegeID = $faculty['collegeID'];

$historyQuery = $conn->prepare("
    SELECT startDate, electionName, endDate, status
    FROM election
    WHERE collegeID = ?
");

if (!$historyQuery) {
    die("History query error: " . $conn->error);
}

$historyQuery->bind_param("i", $collegeID);
$historyQuery->execute();
$historyResult = $historyQuery->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Voting</title>
<style>
    html, body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #d9d9d9;
        overflow: hidden;
    }
    .header {
        width: 100%;
        background-color: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .logout-btn {
        background-color: white;
        color: #4099ff;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 1rem;
        font-size: 1rem;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
        transition: 0.3s;
    }
    .logout-btn:hover {
        background-color: #e6e6e6;
    }
.container {
    display: flex;
    min-height: calc(100vh - 67px);
}

.sidebar {
    width: 220px;
    background-color: #f0f0f0;
    padding: 2rem 1rem;
}

.sidebar a {
    display: block;
    padding: 0.65rem 1rem;
    margin-bottom: 0.6rem;
    color: black;
    text-decoration: none;
    border-radius: 1rem;
}

.sidebar a.active {
    background-color: #a6c8ff;
}
    .main {
        flex: 1;
        padding: 2rem;
        display: flex;
        flex-direction: column;
        gap: 2rem;
        box-sizing: border-box;
    }
    .profile {
        display: flex;
        background-color: #a6c8ff;
        padding: 1rem;
        border-radius: 1rem;
        align-items: center;
        gap: 1rem;
        color: white;
    }
    .profile img {
        width: 100px;
        height: 100px;
        border-radius: 1rem;
        object-fit: cover;
        background-color: #fff;
    }
    .profile-details {
        line-height: 1.5;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: white;
        border-radius: 1rem;
        overflow: hidden;
    }
    table th, table td {
        padding: 0.75rem 1rem;
        text-align: left;
        border-bottom: 1px solid #fff;
    }
    table th {
        background-color: #d0e4ff;
    }
</style>
</head>
<body>
    <div class="header">
        <div>SMC Council Voting</div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
    <div class="container">
        <div class="sidebar">
            <a href="#" class="active">Home</a>
            <a href="facultyElection.php">Election</a>
            <a href="facultyTabulation.php">Winners</a>
            <a href="#">College Officers</a>
        </div>
        <div class="main">
            <div class="profile">
                <img src="https://via.placeholder.com/100" alt="Profile Picture">
                <div class="profile-details">
                    <div>Name: <?php echo htmlspecialchars($faculty['fullName']); ?></div>
                    <div>Department: <?php echo htmlspecialchars($faculty['collegeName']); ?></div>
                    <div>Username: <?php echo htmlspecialchars($faculty['userName']); ?></div>
                    <div>ID Number: <?php echo htmlspecialchars($faculty['IDnumber']); ?></div>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Start Date</th>
                        <th>Election Name</th>
                        <th>End Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $historyResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['startDate']); ?></td>
                        <td><?php echo htmlspecialchars($row['electionName']); ?></td>
                        <td><?php echo htmlspecialchars($row['endDate']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>