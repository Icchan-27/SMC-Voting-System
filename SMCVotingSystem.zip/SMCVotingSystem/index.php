<?php
// Redirect to login.php immediately
header("Location: login.php");
exit; // stop execution after redirect
?>