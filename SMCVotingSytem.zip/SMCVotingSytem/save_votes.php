<?php
session_start();
include 'connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['student_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data) || !isset($data['nominations']) || !is_array($data['nominations']) || count($data['nominations']) === 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid data']);
    exit();
}

$voterId = (int) $_SESSION['student_id'];
$nominations = array_values(array_unique(array_map('intval', $data['nominations'])));

if (count($nominations) === 0) {
    http_response_code(400);
    echo json_encode(['error' => 'No nominations provided']);
    exit();
}

$in = implode(',', $nominations); 
$sql = "
    SELECT DISTINCT ep.election_id
    FROM nomination n
    JOIN election_position ep ON n.election_position_id = ep.election_position_id
    WHERE n.nomination_id IN ($in)
";
$res = $conn->query($sql);
if (!$res) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error (fetch election)']);
    exit();
}

$electionIds = [];
while ($r = $res->fetch_assoc()) $electionIds[] = (int)$r['election_id'];

if (count($electionIds) === 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Nominations not found']);
    exit();
}
if (count($electionIds) > 1) {
    http_response_code(400);
    echo json_encode(['error' => 'Provided nominations belong to multiple elections']);
    exit();
}
$electionId = $electionIds[0];

$sql = "
    SELECT COUNT(*) AS cnt
    FROM votes v
    JOIN nomination n ON v.nomination_id = n.nomination_id
    JOIN election_position ep ON n.election_position_id = ep.election_position_id
    WHERE v.voter_id = {$voterId} AND ep.election_id = {$electionId}
";
$res = $conn->query($sql);
if (!$res) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error (check existing votes)']);
    exit();
}
$cnt = (int)$res->fetch_assoc()['cnt'];
if ($cnt > 0) {
    http_response_code(409);
    echo json_encode(['error' => 'You have already voted in this election']);
    exit();
}

$insertStmt = $conn->prepare("INSERT INTO votes (voter_id, nomination_id, timestamp) VALUES (?, ?, NOW())");
if (!$insertStmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error (prepare insert)']);
    exit();
}

foreach ($nominations as $nid) {
    $nid = (int)$nid;
    $checkRes = $conn->query("SELECT 1 FROM votes WHERE voter_id = {$voterId} AND nomination_id = {$nid} LIMIT 1");
    if ($checkRes && $checkRes->num_rows > 0) {
        continue;
    }
    $insertStmt->bind_param("ii", $voterId, $nid);
    $exec = $insertStmt->execute();
    if ($exec === false) {
        $insertStmt->close();
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save votes']);
        exit();
    }
}
$insertStmt->close();

echo json_encode(['success' => true, 'message' => 'Votes submitted successfully']);
?>