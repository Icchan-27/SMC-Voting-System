<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['studentID']) && !isset($_SESSION['facultyID'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['collegeID'])) {
    die("College not found in session.");
}

$collegeId = (int) $_SESSION['collegeID'];
$latestElection = null;
$winners = [];

$stmt = $conn->prepare("
    SELECT electionID, electionName, startDate, endDate
    FROM election
    WHERE collegeID = ?
      AND status = 'Ended'
    ORDER BY endDate DESC, electionID DESC
    LIMIT 1
");
if (!$stmt) {
    die("Error: " . $conn->error);
}

$stmt->bind_param("i", $collegeId);
$stmt->execute();
$result = $stmt->get_result();
$latestElection = $result->fetch_assoc();
$stmt->close();

if ($latestElection) {
    $electionId = (int) $latestElection['electionID'];

    $stmt = $conn->prepare("
        SELECT 
            o.officerID,
            o.studentID,
            o.status,
            o.positionID,
            s.fullName,
            p.positionName,
            e.electionName
        FROM officers o
        INNER JOIN student s ON o.studentID = s.studentID
        INNER JOIN `position` p ON o.positionID = p.positionID
        INNER JOIN election e ON o.electionID = e.electionID
        WHERE o.electionID = ?
          AND e.collegeID = ?
          AND o.status = 'Current'
        ORDER BY p.positionName ASC
    ");
    if (!$stmt) {
        die("Error: " . $conn->error);
    }

    $stmt->bind_param("ii", $electionId, $collegeId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $winners[] = $row;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latest Election Winners</title>
    <style>
        html, body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #d9d9d9;
            overflow: hidden;
        }

        .header {
            width: 100%;
            background-color: #4099ff;
            color: white;
            padding: 1rem 2rem;
            font-size: 1.5rem;
            font-weight: bold;
            box-sizing: border-box;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logout-btn {
            background-color: white;
            color: #4099ff;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 1rem;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            transition: 0.3s;
        }

        .logout-btn:hover {
            background-color: #e6e6e6;
        }

        .container {
            display: flex;
            min-height: calc(100vh - 67px);
        }

        .sidebar {
            width: 220px;
            background-color: #f0f0f0;
            padding: 2rem 1rem;
            box-sizing: border-box;
        }

        .sidebar a {
            display: block;
            padding: 0.65rem 1rem;
            margin-bottom: 0.6rem;
            color: black;
            text-decoration: none;
            border-radius: 1rem;
        }

        .sidebar a.active {
            background-color: #a6c8ff;
        }

        .main {
            flex: 1;
            padding: 2rem;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            box-sizing: border-box;
            overflow-y: auto;
        }

        .main-card {
            background-color: white;
            border-radius: 1rem;
            padding: 1.5rem;
        }

        .election-info {
            background-color: #a6c8ff;
            color: white;
            padding: 1rem 1.25rem;
            border-radius: 1rem;
            line-height: 1.6;
        }

        .election-info h2 {
            margin: 0 0 0.75rem 0;
            font-size: 1.4rem;
        }

        .section-title {
            margin: 0;
            font-size: 1.25rem;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 1rem;
            overflow: hidden;
        }

        table th, table td {
            padding: 0.75rem 1rem;
            text-align: left;
            border-bottom: 1px solid #fff;
        }

        table th {
            background-color: #d0e4ff;
        }

        table tr:last-child td {
            border-bottom: none;
        }

        .empty {
            background-color: white;
            padding: 1rem 1.25rem;
            border-radius: 1rem;
            color: #444;
        }

        @media (max-width: 768px) {
            html, body {
                overflow: auto;
            }

            .container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                display: flex;
                gap: 0.5rem;
                overflow-x: auto;
                padding: 1rem;
            }

            .sidebar a {
                margin-bottom: 0;
                white-space: nowrap;
            }

            .main {
                padding: 1rem;
            }
        }
    </style>
</head>
<body>

<div class="header">
    <div>SMC Council Voting</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>

<div class="container">
    <div class="sidebar">
        <a href="studentHomePage.php">Home</a>
        <a href="studentNomination.php">Election</a>
        <a href="studentTabulation.php">Winners</a>
        <a href="#" class="active">College Officers</a>
    </div>

    <div class="main">
        <?php if ($latestElection): ?>
            <div class="election-info">
                <h2><?php echo htmlspecialchars($latestElection['electionName']); ?></h2>
                <div><strong>Start Date:</strong> <?php echo htmlspecialchars($latestElection['startDate']); ?></div>
                <div><strong>End Date:</strong> <?php echo htmlspecialchars($latestElection['endDate']); ?></div>
            </div>

            <div class="main-card">
                <h3 class="section-title">Latest Election Winners</h3>

                <?php if (!empty($winners)): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Position</th>
                                <th>Name</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($winners as $winner): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($winner['positionName']); ?></td>
                                    <td><?php echo htmlspecialchars($winner['fullName']); ?></td>
                                    <td><?php echo htmlspecialchars($winner['status']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty">No winners found for the latest ended election.</div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="empty">No ended election found for your college.</div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>