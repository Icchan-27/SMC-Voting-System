<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['faculty_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['election_id'])) {
    header("Location: facultyHomePage.php");
    exit();
}

$electionId = (int) $_GET['election_id'];

$positions = [];
$stmt = $conn->prepare("
    SELECT ep.election_position_id, ep.num_winners
    FROM election_position ep
    WHERE ep.election_id = ?
");
$stmt->bind_param("i", $electionId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $positions[] = $row;
}
$stmt->close();

foreach ($positions as $pos) {
    $posId = $pos['election_position_id'];
    $numWinners = (int)$pos['num_winners'];

    $stmt = $conn->prepare("
        SELECT n.candidate_id, COUNT(v.vote_id) AS total_votes
        FROM nomination n
        LEFT JOIN votes v ON n.nomination_id = v.nomination_id
        WHERE n.election_position_id = ?
        GROUP BY n.candidate_id
        ORDER BY total_votes DESC
        LIMIT ?
    ");
    $stmt->bind_param("ii", $posId, $numWinners);
    $stmt->execute();
    $winners = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    foreach ($winners as $winner) {
        $candidateId = (int)$winner['candidate_id'];
        $votes = (int)$winner['total_votes'];

        $conn->query("
            UPDATE student 
            SET student_position_id = {$posId}, role = 'Officer' 
            WHERE student_id = '{$candidateId}'
        ");

        $conn->query("
            INSERT INTO election_winners (election_position_id, candidate_id, total_votes, election_id)
            VALUES ({$posId}, '{$candidateId}', {$votes}, {$electionId})
        ");
    }
}

$stmt = $conn->prepare("UPDATE elections SET status = 'Done' WHERE election_id = ?");
$stmt->bind_param("i", $electionId);
$stmt->execute();
$stmt->close();

header("Location: facultyHomePage.php");
exit();
?>