<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['student_id']) && !isset($_SESSION['faculty_id'])) {
    header("Location: login.php");
    exit();
}

$elections = [];

if (isset($_SESSION['student_id'])) {
    $studentCollege = $_SESSION['college_id'];
    $stmt = $conn->prepare("SELECT election_id, electionName, organization, college_id
                            FROM elections
                            WHERE status = 'Ongoing'
                            AND college_id = ?");
    $stmt->bind_param("i", $studentCollege);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        echo "<script>
                alert('No ongoing election within your college.');
                window.location.href = 'studentHomePage.php';
                </script>";
        exit();
    }
    while ($row = $result->fetch_assoc()) $elections[] = $row;
    $stmt->close();
}

if (isset($_SESSION['faculty_id'])) {
    $stmt = $conn->prepare("SELECT election_id, electionName, organization, college_id
                            FROM elections
                            WHERE status = 'Ongoing'");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        echo "<script>
                alert('No ongoing elections available.');
                window.location.href = 'facultyHomePage.php';
                </script>";
        exit();
    }
    while ($row = $result->fetch_assoc()) $elections[] = $row;
    $stmt->close();
}

$electionId = $elections[0]['election_id'];
$electionCollege = $elections[0]['college_id'];

$positions = [];
$posStmt = $conn->prepare("SELECT sp.student_position_name 
                        FROM election_position ep
                        INNER JOIN student_positions sp ON sp.student_position_id = ep.student_position_id 
                        WHERE ep.election_id = ?");
$posStmt->bind_param("i", $electionId);
$posStmt->execute();
$res = $posStmt->get_result();
while ($row = $res->fetch_assoc()) $positions[] = $row['student_position_name'];
$posStmt->close();

$students = [];
$stmt = $conn->prepare("SELECT student_id, idNumber, firstName, middleName, lastName FROM student WHERE college_id=?");
$stmt->bind_param("i", $electionCollege);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $students[] = $row;
$stmt->close();

$history = [];
$stmt = $conn->prepare("SELECT n.nomination_id, s.firstName, s.middleName, s.lastName, sp.student_position_name
                        FROM nomination n
                        INNER JOIN student s ON s.student_id = n.candidate_id
                        INNER JOIN election_position ep ON ep.election_position_id = n.election_position_id
                        INNER JOIN student_positions sp ON sp.student_position_id = ep.student_position_id
                        WHERE ep.election_id=?");
$stmt->bind_param("i", $electionId);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) $history[] = $row;
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SMC Council Voting</title>
<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #d9d9d9;
    overflow: hidden;
}

.header {
    width: 100%;
    background: #4099ff;
    color: white;
    padding: 1rem 2rem;
    font-size: 1.5rem;
    font-weight: bold;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
}

.logout-btn {
    background: white;
    color: #4099ff;
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 1rem;
    font-size: 1rem;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    transition: background 0.3s;
}

.logout-btn:hover {
    background: #e6e6e6;
}

.container {
    display: flex;
    height: calc(100vh - 60px);
}

.sidebar {
    width: 220px;
    background: #f0f0f0;
    padding: 2rem 1rem;
    box-sizing: border-box;
}

.sidebar a {
    display: block;
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    text-decoration: none;
    color: black;
    border-radius: 1rem;
}

.sidebar a.active {
    background: #a6c8ff;
}

.main {
    flex: 1;
    padding: 2rem;
    box-sizing: border-box;
    display: flex;
    gap: 2rem;
}

.profile {
    flex: 1;
    background: #a6c8ff;
    padding: 1rem;
    border-radius: 1rem;
    color: white;
    max-height: 500px;
    overflow-y: auto;
}

.candidate-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.candidate-item {
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    background: #4099ff;
    border-radius: 0.75rem;
    cursor: default;
}

.history {
    flex: 2;
    background: white;
    border-radius: 1rem;
    padding: 1rem;
    box-sizing: border-box;
    overflow-y: auto;
    max-height: 500px;
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.95rem;
}

th,
td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #eee;
    text-align: left;
}

th {
    background: #d0e4ff;
}
</style>
</head>
<body>
<div class="header">
    <div>SMC Council Voting</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>
<div class="container">
    <div class="sidebar">
        <a href="facultyHomePage.php">Home</a>
        <a href="#" class="active">Election</a>
        <a href="#">Winners</a>
        <a href="#">College Officers</a>
    </div>
    <div class="main">
        <div class="profile">
            <ul class="candidate-list">
                <?php foreach ($students as $student): ?>
                    <li class="candidate-item">
                        <?= htmlspecialchars($student['firstName'].' '.$student['middleName'].' '.$student['lastName']) ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="history">
            <table>
                <thead>
                    <tr><th>Name</th><th>Position</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($history as $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['firstName'].' '.$row['middleName'].' '.$row['lastName']) ?></td>
                            <td><?= htmlspecialchars($row['student_position_name']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>