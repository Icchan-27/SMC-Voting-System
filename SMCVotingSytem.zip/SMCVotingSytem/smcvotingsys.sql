-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2025 at 06:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smcvotingsys`
--

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--

CREATE TABLE `colleges` (
  `college_id` int(11) NOT NULL,
  `collegeName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `colleges`
--

INSERT INTO `colleges` (`college_id`, `collegeName`) VALUES
(1, 'College of Computer Studies'),
(2, 'College of Nursing'),
(3, 'College of Arts and Science'),
(4, 'College of Engineering'),
(5, 'College of Education'),
(6, 'College of Criminology'),
(7, 'College of Hospitality and Tourism Management'),
(8, 'College of Accountancy'),
(9, 'College of Business Administration');

-- --------------------------------------------------------

--
-- Table structure for table `elections`
--

CREATE TABLE `elections` (
  `election_id` int(11) NOT NULL,
  `electionName` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('Ongoing','Done') NOT NULL DEFAULT 'Ongoing',
  `organization` varchar(50) NOT NULL,
  `created_by` int(11) NOT NULL,
  `college_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `elections`
--

INSERT INTO `elections` (`election_id`, `electionName`, `description`, `start_date`, `end_date`, `status`, `organization`, `created_by`, `college_id`) VALUES
(1, 'CCS Student Council 2025 Election', '', '2025-10-01 22:38:48', NULL, 'Ongoing', 'CCS Student Council', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `election_position`
--

CREATE TABLE `election_position` (
  `election_position_id` int(11) NOT NULL,
  `election_id` int(11) NOT NULL,
  `student_position_id` int(11) NOT NULL,
  `num_winners` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `election_position`
--

INSERT INTO `election_position` (`election_position_id`, `election_id`, `student_position_id`, `num_winners`) VALUES
(2, 1, 6, 1),
(3, 1, 7, 1),
(4, 1, 8, 2),
(5, 1, 9, 5);

-- --------------------------------------------------------

--
-- Table structure for table `election_winners`
--

CREATE TABLE `election_winners` (
  `winner_id` int(11) NOT NULL,
  `election_position_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `total_votes` int(11) NOT NULL,
  `election_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `end_nomination`
--

CREATE TABLE `end_nomination` (
  `end_nomination_id` int(11) NOT NULL,
  `election_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(11) NOT NULL,
  `id_number` char(8) NOT NULL,
  `password` varchar(16) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `college_id` int(11) NOT NULL,
  `faculty_position_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `id_number`, `password`, `firstName`, `middleName`, `lastName`, `email`, `college_id`, `faculty_position_id`) VALUES
(1, 'S21-0121', 'December312023', 'Raiden Shogun', 'Monokami', 'Archon', 'raidenshogunmonokami.archon@my.smciligan.edu.ph', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `faculty_position`
--

CREATE TABLE `faculty_position` (
  `faculty_position_id` int(11) NOT NULL,
  `faculty_position_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_position`
--

INSERT INTO `faculty_position` (`faculty_position_id`, `faculty_position_name`) VALUES
(1, 'Dean'),
(2, 'Faculty'),
(3, 'President');

-- --------------------------------------------------------

--
-- Table structure for table `nomination`
--

CREATE TABLE `nomination` (
  `nomination_id` int(11) NOT NULL,
  `election_position_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `status` enum('Pending','Accepted','Rejected') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nomination_nominators`
--

CREATE TABLE `nomination_nominators` (
  `nomination_nominators_id` int(11) NOT NULL,
  `nomination_id` int(11) NOT NULL,
  `nominator_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `idNumber` char(8) NOT NULL,
  `password` varchar(16) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('Student','Officer') NOT NULL DEFAULT 'Student',
  `college_id` int(11) NOT NULL,
  `student_position_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `idNumber`, `password`, `firstName`, `middleName`, `lastName`, `email`, `role`, `college_id`, `student_position_id`) VALUES
(2, 'C23-0232', '1234', 'Christian James', 'Autida', 'Usman', 'christianjamesautida.usman@my.smciligan.edu.ph', 'Officer', 1, 1),
(3, 'C23-0007', 'alammoyanmarina', 'Janah', 'Alibangbang', 'Baltazar', 'janahalibangbang.baltazar@my.smciligan.edu.ph', 'Officer', 1, 2),
(10, 'C23-0001', '123456789', 'Lee', 'Batumbakal', 'Ho', 'leebatumbakal.ho@my.smciligan.edu.ph', 'Student', 4, NULL),
(11, 'C23-0235', 'April_23', 'Precious Paula', 'Meanowe', 'Nicole', 'preciouspaulameanowe.nicole@my.smciligan.edu.ph', 'Student', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_positions`
--

CREATE TABLE `student_positions` (
  `student_position_id` int(11) NOT NULL,
  `student_position_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_positions`
--

INSERT INTO `student_positions` (`student_position_id`, `student_position_name`) VALUES
(1, 'Governor'),
(2, 'Vice-Governor'),
(3, 'Secretary'),
(4, 'Treasurer'),
(5, 'President'),
(6, 'governor'),
(7, 'vice-governor'),
(8, 'secretary'),
(9, 'representatives');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `vote_id` int(11) NOT NULL,
  `voter_id` int(11) NOT NULL,
  `nomination_id` int(11) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `colleges`
--
ALTER TABLE `colleges`
  ADD PRIMARY KEY (`college_id`);

--
-- Indexes for table `elections`
--
ALTER TABLE `elections`
  ADD PRIMARY KEY (`election_id`),
  ADD KEY `fk_faculty_id` (`created_by`),
  ADD KEY `fk_college_id2` (`college_id`);

--
-- Indexes for table `election_position`
--
ALTER TABLE `election_position`
  ADD PRIMARY KEY (`election_position_id`),
  ADD KEY `fk_student_position_id2` (`student_position_id`),
  ADD KEY `fk_election_id` (`election_id`);

--
-- Indexes for table `election_winners`
--
ALTER TABLE `election_winners`
  ADD PRIMARY KEY (`winner_id`),
  ADD KEY `fk_election_position_id2` (`election_position_id`),
  ADD KEY `fk_candidate_id2` (`candidate_id`),
  ADD KEY `fk_election_id2` (`election_id`);

--
-- Indexes for table `end_nomination`
--
ALTER TABLE `end_nomination`
  ADD PRIMARY KEY (`end_nomination_id`),
  ADD KEY `fk_election_id_2` (`election_id`),
  ADD KEY `fk_student_id_2` (`student_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`),
  ADD KEY `fk_faculty_college_id` (`college_id`),
  ADD KEY `fk_faculty_position_id` (`faculty_position_id`);

--
-- Indexes for table `faculty_position`
--
ALTER TABLE `faculty_position`
  ADD PRIMARY KEY (`faculty_position_id`);

--
-- Indexes for table `nomination`
--
ALTER TABLE `nomination`
  ADD PRIMARY KEY (`nomination_id`),
  ADD KEY `fk_election_position_id` (`election_position_id`),
  ADD KEY `fk_candidate_id` (`candidate_id`);

--
-- Indexes for table `nomination_nominators`
--
ALTER TABLE `nomination_nominators`
  ADD PRIMARY KEY (`nomination_nominators_id`),
  ADD KEY `fk_nomination_id` (`nomination_id`),
  ADD KEY `fk_nominator_id` (`nominator_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `fk_college_id` (`college_id`),
  ADD KEY `fk_student_position_id` (`student_position_id`);

--
-- Indexes for table `student_positions`
--
ALTER TABLE `student_positions`
  ADD PRIMARY KEY (`student_position_id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`vote_id`),
  ADD KEY `fk_nomination_id2` (`nomination_id`),
  ADD KEY `fk_voter_id` (`voter_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `colleges`
--
ALTER TABLE `colleges`
  MODIFY `college_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `elections`
--
ALTER TABLE `elections`
  MODIFY `election_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `election_position`
--
ALTER TABLE `election_position`
  MODIFY `election_position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `election_winners`
--
ALTER TABLE `election_winners`
  MODIFY `winner_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `end_nomination`
--
ALTER TABLE `end_nomination`
  MODIFY `end_nomination_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faculty_position`
--
ALTER TABLE `faculty_position`
  MODIFY `faculty_position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `nomination`
--
ALTER TABLE `nomination`
  MODIFY `nomination_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `nomination_nominators`
--
ALTER TABLE `nomination_nominators`
  MODIFY `nomination_nominators_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student_positions`
--
ALTER TABLE `student_positions`
  MODIFY `student_position_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `vote_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `elections`
--
ALTER TABLE `elections`
  ADD CONSTRAINT `fk_college_id2` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`college_id`),
  ADD CONSTRAINT `fk_faculty_id` FOREIGN KEY (`created_by`) REFERENCES `faculty` (`faculty_id`);

--
-- Constraints for table `election_position`
--
ALTER TABLE `election_position`
  ADD CONSTRAINT `fk_election_id` FOREIGN KEY (`election_id`) REFERENCES `elections` (`election_id`),
  ADD CONSTRAINT `fk_student_position_id2` FOREIGN KEY (`student_position_id`) REFERENCES `student_positions` (`student_position_id`);

--
-- Constraints for table `election_winners`
--
ALTER TABLE `election_winners`
  ADD CONSTRAINT `fk_candidate_id2` FOREIGN KEY (`candidate_id`) REFERENCES `student` (`student_id`),
  ADD CONSTRAINT `fk_election_id2` FOREIGN KEY (`election_id`) REFERENCES `elections` (`election_id`),
  ADD CONSTRAINT `fk_election_position_id2` FOREIGN KEY (`election_position_id`) REFERENCES `election_position` (`election_position_id`);

--
-- Constraints for table `end_nomination`
--
ALTER TABLE `end_nomination`
  ADD CONSTRAINT `fk_election_id_2` FOREIGN KEY (`election_id`) REFERENCES `elections` (`election_id`),
  ADD CONSTRAINT `fk_student_id_2` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `fk_faculty_college_id` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`college_id`),
  ADD CONSTRAINT `fk_faculty_position_id` FOREIGN KEY (`faculty_position_id`) REFERENCES `faculty_position` (`faculty_position_id`);

--
-- Constraints for table `nomination`
--
ALTER TABLE `nomination`
  ADD CONSTRAINT `fk_candidate_id` FOREIGN KEY (`candidate_id`) REFERENCES `student` (`student_id`),
  ADD CONSTRAINT `fk_election_position_id` FOREIGN KEY (`election_position_id`) REFERENCES `election_position` (`election_position_id`);

--
-- Constraints for table `nomination_nominators`
--
ALTER TABLE `nomination_nominators`
  ADD CONSTRAINT `fk_nomination_id` FOREIGN KEY (`nomination_id`) REFERENCES `nomination` (`nomination_id`),
  ADD CONSTRAINT `fk_nominator_id` FOREIGN KEY (`nominator_id`) REFERENCES `student` (`student_id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `fk_college_id` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`college_id`),
  ADD CONSTRAINT `fk_student_position_id` FOREIGN KEY (`student_position_id`) REFERENCES `student_positions` (`student_position_id`);

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `fk_nomination_id2` FOREIGN KEY (`nomination_id`) REFERENCES `nomination` (`nomination_id`),
  ADD CONSTRAINT `fk_voter_id` FOREIGN KEY (`voter_id`) REFERENCES `student` (`student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
