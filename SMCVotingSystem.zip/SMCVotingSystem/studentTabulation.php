<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['studentID'])) {
    header("Location: login.php");
    exit();
}

$studentID = $_SESSION['studentID'];

$stmt = $conn->prepare("
    SELECT studentID, collegeID
    FROM student
    WHERE studentID = ?
");
if (!$stmt) {
    die("Student query error: " . $conn->error);
}
$stmt->bind_param("i", $studentID);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$student) {
    header("Location: login.php");
    exit();
}

$collegeID = $student['collegeID'];

$stmt = $conn->prepare("
    SELECT electionID, electionName, status, showCandidateNames
    FROM election
    WHERE collegeID = ?
    ORDER BY electionID DESC
    LIMIT 1
");
if (!$stmt) {
    die("Election query error: " . $conn->error);
}
$stmt->bind_param("i", $collegeID);
$stmt->execute();
$election = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$election) {
    echo "<script>alert('No election available.'); window.location.href='studentHomePage.php';</script>";
    exit();
}

if ($election['status'] !== 'Voting') {
    echo "<script>alert('Results are not available yet.'); window.location.href='studentHomePage.php';</script>";
    exit();
}

$electionID = (int)$election['electionID'];
$showNames = (int)$election['showCandidateNames'];

$positions = [];
$stmt = $conn->prepare("
    SELECT positionID, positionName, winners
    FROM `position`
    WHERE electionID = ?
    ORDER BY positionID ASC
");
if (!$stmt) {
    die("Position query error: " . $conn->error);
}
$stmt->bind_param("i", $electionID);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $positions[] = $row;
}
$stmt->close();

$results = [];

foreach ($positions as $pos) {
    $positionID = (int)$pos['positionID'];

    $stmt = $conn->prepare("
        SELECT
            n.nominationID,
            s.fullName,
            COUNT(v.voteID) AS votes
        FROM nomination n
        INNER JOIN student s ON s.studentID = n.nomineeID
        LEFT JOIN vote v ON v.nominationID = n.nominationID
        WHERE n.electionID = ?
          AND n.positionID = ?
          AND (n.status = 'Accepted' OR n.status IS NULL)
        GROUP BY n.nominationID, s.fullName
        ORDER BY votes DESC, s.fullName ASC
    ");
    if (!$stmt) {
        die("Result query error: " . $conn->error);
    }
    $stmt->bind_param("ii", $electionID, $positionID);
    $stmt->execute();
    $candidates = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $results[] = [
        'positionName' => $pos['positionName'],
        'winnerLimit'  => (int)$pos['winners'],
        'candidates'   => $candidates
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMC Council Results</title>
<style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background: #d9d9d9;
    }

    .header {
        width: 100%;
        background: #4099ff;
        color: white;
        padding: 1rem 2rem;
        font-size: 1.5rem;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .logout-btn {
        color: white;
        text-decoration: none;
        font-size: 1rem;
        font-weight: bold;
    }

    .container {
        display: flex;
        min-height: calc(100vh - 67px);
    }

    .sidebar {
        width: 220px;
        background: #f0f0f0;
        padding: 2rem 1rem;
        flex-shrink: 0;
    }

    .sidebar a {
        display: block;
        padding: 0.65rem 1rem;
        margin-bottom: 0.6rem;
        color: black;
        text-decoration: none;
        border-radius: 1rem;
    }

    .sidebar a.active {
        background: #a6c8ff;
    }

    .main {
        flex: 1;
        padding: 2rem;
        display: flex;
        gap: 1rem;
        overflow-x: auto;
    }

    .position-card {
        min-width: 300px;
        background: white;
        border-radius: 1rem;
        padding: 1rem;
        box-shadow: 0 2px 6px rgba(0,0,0,.08);
    }

    .position-card h3 {
        margin-top: 0;
        text-align: center;
        color: #4099ff;
    }

    .position-sub {
        text-align: center;
        color: #666;
        margin-bottom: 1rem;
        font-size: 0.95rem;
    }

    .candidate-list {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .candidate-item {
        padding: 0.8rem 0.9rem;
        background: #4099ff;
        color: white;
        border-radius: 0.75rem;
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        font-weight: bold;
    }

    .candidate-item.top {
        background: #2f7ad9;
    }

    .candidate-name {
        flex: 1;
        word-break: break-word;
    }

    .candidate-votes {
        white-space: nowrap;
    }

    .empty-text {
        color: #777;
        text-align: center;
        padding: 1rem 0;
    }

    @media (max-width: 900px) {
        .container {
            flex-direction: column;
        }

        .sidebar {
            width: 100%;
            padding: 1rem;
            display: flex;
            gap: 0.5rem;
            overflow-x: auto;
        }

        .sidebar a {
            margin-bottom: 0;
            white-space: nowrap;
        }

        .main {
            padding: 1rem;
        }
    }
</style>
</head>
<body>
<div class="header">
    <div>SMC Council Results</div>
    <a href="logout.php" class="logout-btn">Logout</a>
</div>

<div class="container">
    <div class="sidebar">
        <a href="studentHomePage.php">Home</a>
        <a href="<?php echo (!empty($_SESSION['isOfficer'])) ? 'nomination.php' : 'studentNomination.php'; ?>">Election</a>
        <a href="#" class="active">Winners</a>
        <a href="electionWinners.php">College Officers</a>
    </div>

    <div class="main">
        <?php foreach ($results as $res): ?>
            <div class="position-card">
                <h3><?= htmlspecialchars($res['positionName']) ?></h3>
                <div class="position-sub">Winners needed: <?= (int)$res['winnerLimit'] ?></div>

                <?php if (!empty($res['candidates'])): ?>
                    <div class="candidate-list">
                        <?php foreach ($res['candidates'] as $index => $cand): ?>
                            <div class="candidate-item <?= $index < $res['winnerLimit'] ? 'top' : '' ?>">
                                <span class="candidate-name">
                                    Rank <?= $index + 1 ?> -
                                    <?= $showNames ? htmlspecialchars($cand['fullName']) : 'Hidden Candidate' ?>
                                </span>
                                <span class="candidate-votes"><?= (int)$cand['votes'] ?> vote(s)</span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-text">No candidates yet.</div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>