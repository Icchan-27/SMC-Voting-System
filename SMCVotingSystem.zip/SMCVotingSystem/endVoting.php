<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['facultyID'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['electionID'])) {
    header("Location: facultyHomePage.php");
    exit();
}

$electionId = (int) $_GET['electionID'];

$conn->begin_transaction();

try {
    $positions = [];
    $governorPositionId = null;
    $viceGovernorPositionId = null;

    $stmt = $conn->prepare("
        SELECT positionID, positionName, winners
        FROM `position`
        WHERE electionID = ?
        ORDER BY positionID ASC
    ");
    if (!$stmt) {
        throw new Exception($conn->error);
    }

    $stmt->bind_param("i", $electionId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $positions[] = $row;

        if (strcasecmp(trim($row['positionName']), 'Governor') === 0) {
            $governorPositionId = (int) $row['positionID'];
        }

        if (strcasecmp(trim($row['positionName']), 'Vice-Governor') === 0) {
            $viceGovernorPositionId = (int) $row['positionID'];
        }
    }
    $stmt->close();

    if ($governorPositionId !== null && $viceGovernorPositionId === null) {
        $stmt = $conn->prepare("
            INSERT INTO `position` (electionID, positionName, winners)
            VALUES (?, 'Vice-Governor', 1)
        ");
        if (!$stmt) {
            throw new Exception($conn->error);
        }

        $stmt->bind_param("i", $electionId);
        $stmt->execute();
        $viceGovernorPositionId = $stmt->insert_id;
        $stmt->close();

        $positions[] = [
            'positionID' => $viceGovernorPositionId,
            'positionName' => 'Vice-Governor',
            'winners' => 1
        ];
    }

    foreach ($positions as $pos) {
        $positionId = (int) $pos['positionID'];
        $positionName = trim($pos['positionName']);
        $numWinners = (int) $pos['winners'];

        if (strcasecmp($positionName, 'Vice-Governor') === 0 && $governorPositionId !== null) {
            continue;
        }

        if (strcasecmp($positionName, 'Governor') === 0 && $viceGovernorPositionId !== null) {
            $stmt = $conn->prepare("
                SELECT n.nomineeID, COUNT(v.voteID) AS totalVotes
                FROM nomination n
                LEFT JOIN vote v ON n.nominationID = v.nominationID
                WHERE n.electionID = ?
                  AND n.positionID = ?
                  AND n.status = 'accepted'
                GROUP BY n.nomineeID
                ORDER BY totalVotes DESC, n.nomineeID ASC
                LIMIT 2
            ");
            if (!$stmt) {
                throw new Exception($conn->error);
            }

            $stmt->bind_param("ii", $electionId, $positionId);
            $stmt->execute();
            $rankedGovernorCandidates = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();

            if (!empty($rankedGovernorCandidates)) {
                $governorStudentId = (int) $rankedGovernorCandidates[0]['nomineeID'];

                $stmt = $conn->prepare("
                    UPDATE officers o
                    INNER JOIN `position` p ON o.positionID = p.positionID
                    SET o.status = 'Former'
                    WHERE o.status = 'Current'
                      AND p.positionName = 'Governor'
                ");
                if (!$stmt) {
                    throw new Exception($conn->error);
                }

                $stmt->execute();
                $stmt->close();

                $stmt = $conn->prepare("
                    INSERT INTO officers (studentID, electionID, status, positionID)
                    VALUES (?, ?, 'Current', ?)
                ");
                if (!$stmt) {
                    throw new Exception($conn->error);
                }

                $stmt->bind_param("iii", $governorStudentId, $electionId, $positionId);
                $stmt->execute();
                $stmt->close();
            }

            if (count($rankedGovernorCandidates) >= 2) {
                $viceGovernorStudentId = (int) $rankedGovernorCandidates[1]['nomineeID'];

                $stmt = $conn->prepare("
                    UPDATE officers o
                    INNER JOIN `position` p ON o.positionID = p.positionID
                    SET o.status = 'Former'
                    WHERE o.status = 'Current'
                      AND p.positionName = 'Vice-Governor'
                ");
                if (!$stmt) {
                    throw new Exception($conn->error);
                }

                $stmt->execute();
                $stmt->close();

                $stmt = $conn->prepare("
                    INSERT INTO officers (studentID, electionID, status, positionID)
                    VALUES (?, ?, 'Current', ?)
                ");
                if (!$stmt) {
                    throw new Exception($conn->error);
                }

                $stmt->bind_param("iii", $viceGovernorStudentId, $electionId, $viceGovernorPositionId);
                $stmt->execute();
                $stmt->close();
            }

            continue;
        }

        $winnerSql = "
            SELECT n.nomineeID, COUNT(v.voteID) AS totalVotes
            FROM nomination n
            LEFT JOIN vote v ON n.nominationID = v.nominationID
            WHERE n.electionID = ?
              AND n.positionID = ?
              AND n.status = 'accepted'
            GROUP BY n.nomineeID
            ORDER BY totalVotes DESC, n.nomineeID ASC
            LIMIT $numWinners
        ";

        $stmt = $conn->prepare($winnerSql);
        if (!$stmt) {
            throw new Exception($conn->error);
        }

        $stmt->bind_param("ii", $electionId, $positionId);
        $stmt->execute();
        $winners = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        foreach ($winners as $winner) {
            $studentId = (int) $winner['nomineeID'];

            $stmt = $conn->prepare("
                UPDATE officers o
                INNER JOIN `position` p ON o.positionID = p.positionID
                SET o.status = 'Former'
                WHERE o.status = 'Current'
                  AND p.positionName = ?
            ");
            if (!$stmt) {
                throw new Exception($conn->error);
            }

            $stmt->bind_param("s", $positionName);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("
                INSERT INTO officers (studentID, electionID, status, positionID)
                VALUES (?, ?, 'Current', ?)
            ");
            if (!$stmt) {
                throw new Exception($conn->error);
            }

            $stmt->bind_param("iii", $studentId, $electionId, $positionId);
            $stmt->execute();
            $stmt->close();
        }
    }

    $stmt = $conn->prepare("
        UPDATE election
        SET status = 'Ended', endDate = NOW()
        WHERE electionID = ?
    ");
    if (!$stmt) {
        throw new Exception($conn->error);
    }

    $stmt->bind_param("i", $electionId);
    $stmt->execute();
    $stmt->close();

    $conn->commit();

    header("Location: facultyHomePage.php");
    exit();
} catch (Exception $e) {
    $conn->rollback();
    die("Error ending voting: " . $e->getMessage());
}
?>